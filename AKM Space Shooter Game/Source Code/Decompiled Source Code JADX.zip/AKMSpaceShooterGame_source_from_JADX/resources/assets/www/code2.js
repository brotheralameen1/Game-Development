gdjs.GameCode = {};
gdjs.GameCode.GDScoreObjects1= [];
gdjs.GameCode.GDScoreObjects2= [];
gdjs.GameCode.GDScoreObjects3= [];
gdjs.GameCode.GDPlayerObjects1= [];
gdjs.GameCode.GDPlayerObjects2= [];
gdjs.GameCode.GDPlayerObjects3= [];
gdjs.GameCode.GDBulletObjects1= [];
gdjs.GameCode.GDBulletObjects2= [];
gdjs.GameCode.GDBulletObjects3= [];
gdjs.GameCode.GDEnemyObjects1= [];
gdjs.GameCode.GDEnemyObjects2= [];
gdjs.GameCode.GDEnemyObjects3= [];
gdjs.GameCode.GDEnemy2Objects1= [];
gdjs.GameCode.GDEnemy2Objects2= [];
gdjs.GameCode.GDEnemy2Objects3= [];
gdjs.GameCode.GDBackgroundObjects1= [];
gdjs.GameCode.GDBackgroundObjects2= [];
gdjs.GameCode.GDBackgroundObjects3= [];
gdjs.GameCode.GDBorderObjects1= [];
gdjs.GameCode.GDBorderObjects2= [];
gdjs.GameCode.GDBorderObjects3= [];
gdjs.GameCode.GDLeftArrowButtonObjects1= [];
gdjs.GameCode.GDLeftArrowButtonObjects2= [];
gdjs.GameCode.GDLeftArrowButtonObjects3= [];
gdjs.GameCode.GDRightArrowButtonObjects1= [];
gdjs.GameCode.GDRightArrowButtonObjects2= [];
gdjs.GameCode.GDRightArrowButtonObjects3= [];

gdjs.GameCode.conditionTrue_0 = {val:false};
gdjs.GameCode.condition0IsTrue_0 = {val:false};
gdjs.GameCode.condition1IsTrue_0 = {val:false};


gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.GameCode.GDBulletObjects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDEnemyObjects2Objects = Hashtable.newFrom({"Enemy": gdjs.GameCode.GDEnemyObjects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDEnemy2Objects2Objects = Hashtable.newFrom({"Enemy2": gdjs.GameCode.GDEnemy2Objects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.GameCode.GDBulletObjects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDEnemyObjects2Objects = Hashtable.newFrom({"Enemy": gdjs.GameCode.GDEnemyObjects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.GameCode.GDBulletObjects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDEnemy2Objects2Objects = Hashtable.newFrom({"Enemy2": gdjs.GameCode.GDEnemy2Objects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDEnemyObjects2Objects = Hashtable.newFrom({"Enemy": gdjs.GameCode.GDEnemyObjects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.GameCode.GDPlayerObjects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDEnemy2Objects2Objects = Hashtable.newFrom({"Enemy2": gdjs.GameCode.GDEnemy2Objects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.GameCode.GDPlayerObjects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBorderObjects2Objects = Hashtable.newFrom({"Border": gdjs.GameCode.GDBorderObjects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.GameCode.GDPlayerObjects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBorderObjects2Objects = Hashtable.newFrom({"Border": gdjs.GameCode.GDBorderObjects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBorderObjects2Objects = Hashtable.newFrom({"Border": gdjs.GameCode.GDBorderObjects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDEnemyObjects2Objects = Hashtable.newFrom({"Enemy": gdjs.GameCode.GDEnemyObjects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBorderObjects2Objects = Hashtable.newFrom({"Border": gdjs.GameCode.GDBorderObjects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBorderObjects2Objects = Hashtable.newFrom({"Border": gdjs.GameCode.GDBorderObjects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDEnemy2Objects2Objects = Hashtable.newFrom({"Enemy2": gdjs.GameCode.GDEnemy2Objects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBorderObjects2Objects = Hashtable.newFrom({"Border": gdjs.GameCode.GDBorderObjects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDRightArrowButtonObjects2Objects = Hashtable.newFrom({"RightArrowButton": gdjs.GameCode.GDRightArrowButtonObjects2});gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDLeftArrowButtonObjects1Objects = Hashtable.newFrom({"LeftArrowButton": gdjs.GameCode.GDLeftArrowButtonObjects1});gdjs.GameCode.eventsList0 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.3, "BulletFire");
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);
gdjs.GameCode.GDBulletObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBulletObjects2Objects, (( gdjs.GameCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects2[0].getPointX("")), (( gdjs.GameCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects2[0].getPointY("")), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BulletFire");
}{gdjs.evtTools.sound.playSound(runtimeScene, "BulletFire.wav", false, 100, 1);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.GameCode.GDBulletObjects2);
{for(var i = 0, len = gdjs.GameCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBulletObjects2[i].addPolarForce(270, 300, 0);
}
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.8, "enemyscene");
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.GameCode.GDEnemyObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDEnemyObjects2Objects, gdjs.random(570), -(49), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "enemyscene");
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.GameCode.GDEnemyObjects2);
{for(var i = 0, len = gdjs.GameCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDEnemyObjects2[i].addPolarForce(90, 100, 0);
}
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 5, "ec2");
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.GameCode.GDEnemy2Objects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDEnemy2Objects2Objects, gdjs.random(580), gdjs.random(-(49)), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "ec2");
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.GameCode.GDEnemy2Objects2);
{for(var i = 0, len = gdjs.GameCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.GameCode.GDEnemy2Objects2[i].addPolarForce(90, 50, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.GameCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.GameCode.GDEnemyObjects2);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBulletObjects2Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDEnemyObjects2Objects, false, runtimeScene, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDBulletObjects2 */
/* Reuse gdjs.GameCode.GDEnemyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.GameCode.GDScoreObjects2);
{for(var i = 0, len = gdjs.GameCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDEnemyObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "EnemyDefeat.wav", false, 100, 1);
}{runtimeScene.getVariables().get("Score").add(1);
}{for(var i = 0, len = gdjs.GameCode.GDScoreObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDScoreObjects2[i].setString("" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Score"))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.GameCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.GameCode.GDEnemy2Objects2);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBulletObjects2Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDEnemy2Objects2Objects, false, runtimeScene, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDBulletObjects2 */
/* Reuse gdjs.GameCode.GDEnemy2Objects2 */
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.GameCode.GDScoreObjects2);
{for(var i = 0, len = gdjs.GameCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.GameCode.GDEnemy2Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "EnemyDefeat.wav", false, 100, 1);
}{runtimeScene.getVariables().get("Score").add(1);
}{for(var i = 0, len = gdjs.GameCode.GDScoreObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDScoreObjects2[i].setString("" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Score"))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.GameCode.GDEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDEnemyObjects2Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDPlayerObjects2Objects, false, runtimeScene, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game_Over", false);
}{gdjs.adMob.loadInterstitial("ca-app-pub-9806557752529441/1473947398", "", false);
}{gdjs.adMob.showInterstitial();
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.GameCode.GDEnemy2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDEnemy2Objects2Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDPlayerObjects2Objects, false, runtimeScene, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game_Over", false);
}{gdjs.adMob.loadInterstitial("ca-app-pub-9806557752529441/1473947398", "", false);
}{gdjs.adMob.showInterstitial();
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Border"), gdjs.GameCode.GDBorderObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBorderObjects2Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDPlayerObjects2Objects, false, runtimeScene, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDBorderObjects2 */
/* Reuse gdjs.GameCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects2[i].separateFromObjectsList(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBorderObjects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Border"), gdjs.GameCode.GDBorderObjects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.GameCode.GDEnemyObjects2);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBorderObjects2Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDEnemyObjects2Objects, false, runtimeScene, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDBorderObjects2 */
/* Reuse gdjs.GameCode.GDEnemyObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDEnemyObjects2[i].separateFromObjectsList(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBorderObjects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Border"), gdjs.GameCode.GDBorderObjects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.GameCode.GDEnemy2Objects2);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBorderObjects2Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDEnemy2Objects2Objects, false, runtimeScene, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDBorderObjects2 */
/* Reuse gdjs.GameCode.GDEnemy2Objects2 */
{for(var i = 0, len = gdjs.GameCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.GameCode.GDEnemy2Objects2[i].separateFromObjectsList(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBorderObjects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RightArrowButton"), gdjs.GameCode.GDRightArrowButtonObjects2);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDRightArrowButtonObjects2Objects, runtimeScene, true, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects2[i].addPolarForce(0, 300, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("LeftArrowButton"), gdjs.GameCode.GDLeftArrowButtonObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDLeftArrowButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects1[i].addPolarForce(180, 300, 0);
}
}}

}


};gdjs.GameCode.eventsList1 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Score")) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("HScore"));
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().get("HScore").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Score")));
}{gdjs.evtTools.storage.writeNumberInJSONFile("Save", "HScore", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("HScore")));
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.GameCode.GDScoreObjects1);
{for(var i = 0, len = gdjs.GameCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDScoreObjects1[i].setString("" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Score"))));
}
}}

}


};gdjs.GameCode.eventsList2 = function(runtimeScene) {

{


gdjs.GameCode.eventsList0(runtimeScene);
}


{


gdjs.GameCode.eventsList1(runtimeScene);
}


};

gdjs.GameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameCode.GDScoreObjects1.length = 0;
gdjs.GameCode.GDScoreObjects2.length = 0;
gdjs.GameCode.GDScoreObjects3.length = 0;
gdjs.GameCode.GDPlayerObjects1.length = 0;
gdjs.GameCode.GDPlayerObjects2.length = 0;
gdjs.GameCode.GDPlayerObjects3.length = 0;
gdjs.GameCode.GDBulletObjects1.length = 0;
gdjs.GameCode.GDBulletObjects2.length = 0;
gdjs.GameCode.GDBulletObjects3.length = 0;
gdjs.GameCode.GDEnemyObjects1.length = 0;
gdjs.GameCode.GDEnemyObjects2.length = 0;
gdjs.GameCode.GDEnemyObjects3.length = 0;
gdjs.GameCode.GDEnemy2Objects1.length = 0;
gdjs.GameCode.GDEnemy2Objects2.length = 0;
gdjs.GameCode.GDEnemy2Objects3.length = 0;
gdjs.GameCode.GDBackgroundObjects1.length = 0;
gdjs.GameCode.GDBackgroundObjects2.length = 0;
gdjs.GameCode.GDBackgroundObjects3.length = 0;
gdjs.GameCode.GDBorderObjects1.length = 0;
gdjs.GameCode.GDBorderObjects2.length = 0;
gdjs.GameCode.GDBorderObjects3.length = 0;
gdjs.GameCode.GDLeftArrowButtonObjects1.length = 0;
gdjs.GameCode.GDLeftArrowButtonObjects2.length = 0;
gdjs.GameCode.GDLeftArrowButtonObjects3.length = 0;
gdjs.GameCode.GDRightArrowButtonObjects1.length = 0;
gdjs.GameCode.GDRightArrowButtonObjects2.length = 0;
gdjs.GameCode.GDRightArrowButtonObjects3.length = 0;

gdjs.GameCode.eventsList2(runtimeScene);
return;

}

gdjs['GameCode'] = gdjs.GameCode;
