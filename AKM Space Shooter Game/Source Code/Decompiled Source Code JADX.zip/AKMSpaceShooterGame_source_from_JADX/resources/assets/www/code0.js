gdjs.SplashCode = {};
gdjs.SplashCode.GDScoreObjects1= [];
gdjs.SplashCode.GDScoreObjects2= [];
gdjs.SplashCode.GDLoadingObjects1= [];
gdjs.SplashCode.GDLoadingObjects2= [];
gdjs.SplashCode.GDImageObjects1= [];
gdjs.SplashCode.GDImageObjects2= [];
gdjs.SplashCode.GDGame_95NameObjects1= [];
gdjs.SplashCode.GDGame_95NameObjects2= [];

gdjs.SplashCode.conditionTrue_0 = {val:false};
gdjs.SplashCode.condition0IsTrue_0 = {val:false};
gdjs.SplashCode.condition1IsTrue_0 = {val:false};


gdjs.SplashCode.eventsList0 = function(runtimeScene) {

{


gdjs.SplashCode.condition0IsTrue_0.val = false;
{
gdjs.SplashCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 5, "Load");
}if (gdjs.SplashCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Load");
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main_Menu", false);
}{gdjs.adMob.loadInterstitial("ca-app-pub-9806557752529441/1473947398", "", true);
}{gdjs.adMob.showInterstitial();
}}

}


};gdjs.SplashCode.eventsList1 = function(runtimeScene) {

{


gdjs.SplashCode.eventsList0(runtimeScene);
}


};

gdjs.SplashCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.SplashCode.GDScoreObjects1.length = 0;
gdjs.SplashCode.GDScoreObjects2.length = 0;
gdjs.SplashCode.GDLoadingObjects1.length = 0;
gdjs.SplashCode.GDLoadingObjects2.length = 0;
gdjs.SplashCode.GDImageObjects1.length = 0;
gdjs.SplashCode.GDImageObjects2.length = 0;
gdjs.SplashCode.GDGame_95NameObjects1.length = 0;
gdjs.SplashCode.GDGame_95NameObjects2.length = 0;

gdjs.SplashCode.eventsList1(runtimeScene);
return;

}

gdjs['SplashCode'] = gdjs.SplashCode;
