gdjs.GuideCode = {};
gdjs.GuideCode.GDScoreObjects1= [];
gdjs.GuideCode.GDScoreObjects2= [];
gdjs.GuideCode.GDMain_95Menu1Objects1= [];
gdjs.GuideCode.GDMain_95Menu1Objects2= [];
gdjs.GuideCode.GDGuideObjects1= [];
gdjs.GuideCode.GDGuideObjects2= [];
gdjs.GuideCode.GDGuide2Objects1= [];
gdjs.GuideCode.GDGuide2Objects2= [];
gdjs.GuideCode.GDGuide1Objects1= [];
gdjs.GuideCode.GDGuide1Objects2= [];
gdjs.GuideCode.GDFunObjects1= [];
gdjs.GuideCode.GDFunObjects2= [];
gdjs.GuideCode.GDMain_95MenuObjects1= [];
gdjs.GuideCode.GDMain_95MenuObjects2= [];

gdjs.GuideCode.conditionTrue_0 = {val:false};
gdjs.GuideCode.condition0IsTrue_0 = {val:false};
gdjs.GuideCode.condition1IsTrue_0 = {val:false};
gdjs.GuideCode.condition2IsTrue_0 = {val:false};


gdjs.GuideCode.mapOfGDgdjs_46GuideCode_46GDMain_9595Menu1Objects1Objects = Hashtable.newFrom({"Main_Menu1": gdjs.GuideCode.GDMain_95Menu1Objects1});gdjs.GuideCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Main_Menu1"), gdjs.GuideCode.GDMain_95Menu1Objects1);

gdjs.GuideCode.condition0IsTrue_0.val = false;
gdjs.GuideCode.condition1IsTrue_0.val = false;
{
gdjs.GuideCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GuideCode.mapOfGDgdjs_46GuideCode_46GDMain_9595Menu1Objects1Objects, runtimeScene, true, false);
}if ( gdjs.GuideCode.condition0IsTrue_0.val ) {
{
gdjs.GuideCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.GuideCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main_Menu", false);
}{gdjs.adMob.loadInterstitial("ca-app-pub-9806557752529441/1473947398", "", false);
}{gdjs.adMob.showInterstitial();
}}

}


};gdjs.GuideCode.eventsList1 = function(runtimeScene) {

{


gdjs.GuideCode.eventsList0(runtimeScene);
}


};

gdjs.GuideCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GuideCode.GDScoreObjects1.length = 0;
gdjs.GuideCode.GDScoreObjects2.length = 0;
gdjs.GuideCode.GDMain_95Menu1Objects1.length = 0;
gdjs.GuideCode.GDMain_95Menu1Objects2.length = 0;
gdjs.GuideCode.GDGuideObjects1.length = 0;
gdjs.GuideCode.GDGuideObjects2.length = 0;
gdjs.GuideCode.GDGuide2Objects1.length = 0;
gdjs.GuideCode.GDGuide2Objects2.length = 0;
gdjs.GuideCode.GDGuide1Objects1.length = 0;
gdjs.GuideCode.GDGuide1Objects2.length = 0;
gdjs.GuideCode.GDFunObjects1.length = 0;
gdjs.GuideCode.GDFunObjects2.length = 0;
gdjs.GuideCode.GDMain_95MenuObjects1.length = 0;
gdjs.GuideCode.GDMain_95MenuObjects2.length = 0;

gdjs.GuideCode.eventsList1(runtimeScene);
return;

}

gdjs['GuideCode'] = gdjs.GuideCode;
