gdjs.Terms_95and_95ConditionsCode = {};
gdjs.Terms_95and_95ConditionsCode.GDScoreObjects1= [];
gdjs.Terms_95and_95ConditionsCode.GDScoreObjects2= [];
gdjs.Terms_95and_95ConditionsCode.GDMain_95MenuObjects1= [];
gdjs.Terms_95and_95ConditionsCode.GDMain_95MenuObjects2= [];
gdjs.Terms_95and_95ConditionsCode.GDPPTNCObjects1= [];
gdjs.Terms_95and_95ConditionsCode.GDPPTNCObjects2= [];
gdjs.Terms_95and_95ConditionsCode.GDPPTNC1Objects1= [];
gdjs.Terms_95and_95ConditionsCode.GDPPTNC1Objects2= [];
gdjs.Terms_95and_95ConditionsCode.GDMain_95Menu1Objects1= [];
gdjs.Terms_95and_95ConditionsCode.GDMain_95Menu1Objects2= [];
gdjs.Terms_95and_95ConditionsCode.GDPPTNC2Objects1= [];
gdjs.Terms_95and_95ConditionsCode.GDPPTNC2Objects2= [];

gdjs.Terms_95and_95ConditionsCode.conditionTrue_0 = {val:false};
gdjs.Terms_95and_95ConditionsCode.condition0IsTrue_0 = {val:false};
gdjs.Terms_95and_95ConditionsCode.condition1IsTrue_0 = {val:false};
gdjs.Terms_95and_95ConditionsCode.condition2IsTrue_0 = {val:false};


gdjs.Terms_95and_95ConditionsCode.mapOfGDgdjs_46Terms_9595and_9595ConditionsCode_46GDMain_9595MenuObjects1Objects = Hashtable.newFrom({"Main_Menu": gdjs.Terms_95and_95ConditionsCode.GDMain_95MenuObjects1});gdjs.Terms_95and_95ConditionsCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Main_Menu"), gdjs.Terms_95and_95ConditionsCode.GDMain_95MenuObjects1);

gdjs.Terms_95and_95ConditionsCode.condition0IsTrue_0.val = false;
gdjs.Terms_95and_95ConditionsCode.condition1IsTrue_0.val = false;
{
gdjs.Terms_95and_95ConditionsCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Terms_95and_95ConditionsCode.mapOfGDgdjs_46Terms_9595and_9595ConditionsCode_46GDMain_9595MenuObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Terms_95and_95ConditionsCode.condition0IsTrue_0.val ) {
{
gdjs.Terms_95and_95ConditionsCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.Terms_95and_95ConditionsCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main_Menu", false);
}{gdjs.adMob.loadInterstitial("ca-app-pub-9806557752529441/1473947398", "", false);
}{gdjs.adMob.showInterstitial();
}}

}


};gdjs.Terms_95and_95ConditionsCode.eventsList1 = function(runtimeScene) {

{


gdjs.Terms_95and_95ConditionsCode.eventsList0(runtimeScene);
}


};

gdjs.Terms_95and_95ConditionsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Terms_95and_95ConditionsCode.GDScoreObjects1.length = 0;
gdjs.Terms_95and_95ConditionsCode.GDScoreObjects2.length = 0;
gdjs.Terms_95and_95ConditionsCode.GDMain_95MenuObjects1.length = 0;
gdjs.Terms_95and_95ConditionsCode.GDMain_95MenuObjects2.length = 0;
gdjs.Terms_95and_95ConditionsCode.GDPPTNCObjects1.length = 0;
gdjs.Terms_95and_95ConditionsCode.GDPPTNCObjects2.length = 0;
gdjs.Terms_95and_95ConditionsCode.GDPPTNC1Objects1.length = 0;
gdjs.Terms_95and_95ConditionsCode.GDPPTNC1Objects2.length = 0;
gdjs.Terms_95and_95ConditionsCode.GDMain_95Menu1Objects1.length = 0;
gdjs.Terms_95and_95ConditionsCode.GDMain_95Menu1Objects2.length = 0;
gdjs.Terms_95and_95ConditionsCode.GDPPTNC2Objects1.length = 0;
gdjs.Terms_95and_95ConditionsCode.GDPPTNC2Objects2.length = 0;

gdjs.Terms_95and_95ConditionsCode.eventsList1(runtimeScene);
return;

}

gdjs['Terms_95and_95ConditionsCode'] = gdjs.Terms_95and_95ConditionsCode;
