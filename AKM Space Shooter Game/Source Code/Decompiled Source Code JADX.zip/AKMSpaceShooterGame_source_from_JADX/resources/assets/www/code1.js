gdjs.Main_95MenuCode = {};
gdjs.Main_95MenuCode.GDScoreObjects1= [];
gdjs.Main_95MenuCode.GDScoreObjects2= [];
gdjs.Main_95MenuCode.GDScoreObjects3= [];
gdjs.Main_95MenuCode.GDPlayObjects1= [];
gdjs.Main_95MenuCode.GDPlayObjects2= [];
gdjs.Main_95MenuCode.GDPlayObjects3= [];
gdjs.Main_95MenuCode.GDQuit_95GameObjects1= [];
gdjs.Main_95MenuCode.GDQuit_95GameObjects2= [];
gdjs.Main_95MenuCode.GDQuit_95GameObjects3= [];
gdjs.Main_95MenuCode.GDPoints_95SystemObjects1= [];
gdjs.Main_95MenuCode.GDPoints_95SystemObjects2= [];
gdjs.Main_95MenuCode.GDPoints_95SystemObjects3= [];
gdjs.Main_95MenuCode.GDPPTNCObjects1= [];
gdjs.Main_95MenuCode.GDPPTNCObjects2= [];
gdjs.Main_95MenuCode.GDPPTNCObjects3= [];
gdjs.Main_95MenuCode.GDGuideObjects1= [];
gdjs.Main_95MenuCode.GDGuideObjects2= [];
gdjs.Main_95MenuCode.GDGuideObjects3= [];
gdjs.Main_95MenuCode.GDYouTubeObjects1= [];
gdjs.Main_95MenuCode.GDYouTubeObjects2= [];
gdjs.Main_95MenuCode.GDYouTubeObjects3= [];
gdjs.Main_95MenuCode.GDWebsiteObjects1= [];
gdjs.Main_95MenuCode.GDWebsiteObjects2= [];
gdjs.Main_95MenuCode.GDWebsiteObjects3= [];
gdjs.Main_95MenuCode.GDMain_95MenuObjects1= [];
gdjs.Main_95MenuCode.GDMain_95MenuObjects2= [];
gdjs.Main_95MenuCode.GDMain_95MenuObjects3= [];
gdjs.Main_95MenuCode.GDGuide1Objects1= [];
gdjs.Main_95MenuCode.GDGuide1Objects2= [];
gdjs.Main_95MenuCode.GDGuide1Objects3= [];
gdjs.Main_95MenuCode.GDPPTNC1Objects1= [];
gdjs.Main_95MenuCode.GDPPTNC1Objects2= [];
gdjs.Main_95MenuCode.GDPPTNC1Objects3= [];
gdjs.Main_95MenuCode.GDPlay2Objects1= [];
gdjs.Main_95MenuCode.GDPlay2Objects2= [];
gdjs.Main_95MenuCode.GDPlay2Objects3= [];
gdjs.Main_95MenuCode.GDQuitObjects1= [];
gdjs.Main_95MenuCode.GDQuitObjects2= [];
gdjs.Main_95MenuCode.GDQuitObjects3= [];
gdjs.Main_95MenuCode.GDHighScore1Objects1= [];
gdjs.Main_95MenuCode.GDHighScore1Objects2= [];
gdjs.Main_95MenuCode.GDHighScore1Objects3= [];
gdjs.Main_95MenuCode.GDHScoreObjects1= [];
gdjs.Main_95MenuCode.GDHScoreObjects2= [];
gdjs.Main_95MenuCode.GDHScoreObjects3= [];
gdjs.Main_95MenuCode.GDMain_95Menu1Objects1= [];
gdjs.Main_95MenuCode.GDMain_95Menu1Objects2= [];
gdjs.Main_95MenuCode.GDMain_95Menu1Objects3= [];
gdjs.Main_95MenuCode.GDYTObjects1= [];
gdjs.Main_95MenuCode.GDYTObjects2= [];
gdjs.Main_95MenuCode.GDYTObjects3= [];
gdjs.Main_95MenuCode.GDWebObjects1= [];
gdjs.Main_95MenuCode.GDWebObjects2= [];
gdjs.Main_95MenuCode.GDWebObjects3= [];
gdjs.Main_95MenuCode.GDAveObjects1= [];
gdjs.Main_95MenuCode.GDAveObjects2= [];
gdjs.Main_95MenuCode.GDAveObjects3= [];

gdjs.Main_95MenuCode.conditionTrue_0 = {val:false};
gdjs.Main_95MenuCode.condition0IsTrue_0 = {val:false};
gdjs.Main_95MenuCode.condition1IsTrue_0 = {val:false};
gdjs.Main_95MenuCode.condition2IsTrue_0 = {val:false};


gdjs.Main_95MenuCode.mapOfGDgdjs_46Main_9595MenuCode_46GDPlayObjects2Objects = Hashtable.newFrom({"Play": gdjs.Main_95MenuCode.GDPlayObjects2});gdjs.Main_95MenuCode.mapOfGDgdjs_46Main_9595MenuCode_46GDQuit_9595GameObjects2Objects = Hashtable.newFrom({"Quit_Game": gdjs.Main_95MenuCode.GDQuit_95GameObjects2});gdjs.Main_95MenuCode.mapOfGDgdjs_46Main_9595MenuCode_46GDGuideObjects2Objects = Hashtable.newFrom({"Guide": gdjs.Main_95MenuCode.GDGuideObjects2});gdjs.Main_95MenuCode.mapOfGDgdjs_46Main_9595MenuCode_46GDPPTNCObjects2Objects = Hashtable.newFrom({"PPTNC": gdjs.Main_95MenuCode.GDPPTNCObjects2});gdjs.Main_95MenuCode.mapOfGDgdjs_46Main_9595MenuCode_46GDYouTubeObjects2Objects = Hashtable.newFrom({"YouTube": gdjs.Main_95MenuCode.GDYouTubeObjects2});gdjs.Main_95MenuCode.mapOfGDgdjs_46Main_9595MenuCode_46GDWebsiteObjects1Objects = Hashtable.newFrom({"Website": gdjs.Main_95MenuCode.GDWebsiteObjects1});gdjs.Main_95MenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.Main_95MenuCode.GDPlayObjects2);

gdjs.Main_95MenuCode.condition0IsTrue_0.val = false;
gdjs.Main_95MenuCode.condition1IsTrue_0.val = false;
{
gdjs.Main_95MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_95MenuCode.mapOfGDgdjs_46Main_9595MenuCode_46GDPlayObjects2Objects, runtimeScene, true, false);
}if ( gdjs.Main_95MenuCode.condition0IsTrue_0.val ) {
{
gdjs.Main_95MenuCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.Main_95MenuCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game", false);
}{gdjs.adMob.loadInterstitial("ca-app-pub-9806557752529441/1473947398", "", false);
}{gdjs.adMob.showInterstitial();
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quit_Game"), gdjs.Main_95MenuCode.GDQuit_95GameObjects2);

gdjs.Main_95MenuCode.condition0IsTrue_0.val = false;
gdjs.Main_95MenuCode.condition1IsTrue_0.val = false;
{
gdjs.Main_95MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_95MenuCode.mapOfGDgdjs_46Main_9595MenuCode_46GDQuit_9595GameObjects2Objects, runtimeScene, true, false);
}if ( gdjs.Main_95MenuCode.condition0IsTrue_0.val ) {
{
gdjs.Main_95MenuCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.Main_95MenuCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Guide"), gdjs.Main_95MenuCode.GDGuideObjects2);

gdjs.Main_95MenuCode.condition0IsTrue_0.val = false;
gdjs.Main_95MenuCode.condition1IsTrue_0.val = false;
{
gdjs.Main_95MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_95MenuCode.mapOfGDgdjs_46Main_9595MenuCode_46GDGuideObjects2Objects, runtimeScene, true, false);
}if ( gdjs.Main_95MenuCode.condition0IsTrue_0.val ) {
{
gdjs.Main_95MenuCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.Main_95MenuCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Guide", false);
}{gdjs.adMob.loadInterstitial("ca-app-pub-9806557752529441/1473947398", "", false);
}{gdjs.adMob.showInterstitial();
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("PPTNC"), gdjs.Main_95MenuCode.GDPPTNCObjects2);

gdjs.Main_95MenuCode.condition0IsTrue_0.val = false;
gdjs.Main_95MenuCode.condition1IsTrue_0.val = false;
{
gdjs.Main_95MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_95MenuCode.mapOfGDgdjs_46Main_9595MenuCode_46GDPPTNCObjects2Objects, runtimeScene, true, false);
}if ( gdjs.Main_95MenuCode.condition0IsTrue_0.val ) {
{
gdjs.Main_95MenuCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.Main_95MenuCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Terms_and_Conditions", false);
}{gdjs.adMob.loadInterstitial("ca-app-pub-9806557752529441/1473947398", "", false);
}{gdjs.adMob.showInterstitial();
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("YouTube"), gdjs.Main_95MenuCode.GDYouTubeObjects2);

gdjs.Main_95MenuCode.condition0IsTrue_0.val = false;
gdjs.Main_95MenuCode.condition1IsTrue_0.val = false;
{
gdjs.Main_95MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_95MenuCode.mapOfGDgdjs_46Main_9595MenuCode_46GDYouTubeObjects2Objects, runtimeScene, true, false);
}if ( gdjs.Main_95MenuCode.condition0IsTrue_0.val ) {
{
gdjs.Main_95MenuCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.Main_95MenuCode.condition1IsTrue_0.val) {
{gdjs.evtTools.window.openURL("https://www.youtube.com/channel/UCRmZnjgfrD7al_h-cyOdQLA", runtimeScene);
}{gdjs.adMob.loadInterstitial("ca-app-pub-9806557752529441/1473947398", "", false);
}{gdjs.adMob.showInterstitial();
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Website"), gdjs.Main_95MenuCode.GDWebsiteObjects1);

gdjs.Main_95MenuCode.condition0IsTrue_0.val = false;
gdjs.Main_95MenuCode.condition1IsTrue_0.val = false;
{
gdjs.Main_95MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Main_95MenuCode.mapOfGDgdjs_46Main_9595MenuCode_46GDWebsiteObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Main_95MenuCode.condition0IsTrue_0.val ) {
{
gdjs.Main_95MenuCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.Main_95MenuCode.condition1IsTrue_0.val) {
{gdjs.evtTools.window.openURL("https://www.alameentechhelp.site123.me/", runtimeScene);
}{gdjs.adMob.loadInterstitial("ca-app-pub-9806557752529441/1473947398", "", false);
}{gdjs.adMob.showInterstitial();
}}

}


};gdjs.Main_95MenuCode.eventsList1 = function(runtimeScene) {

{


gdjs.Main_95MenuCode.condition0IsTrue_0.val = false;
{
gdjs.Main_95MenuCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("Save", "HScore");
}if (gdjs.Main_95MenuCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.Main_95MenuCode.GDScoreObjects2);
{gdjs.evtTools.storage.readNumberFromJSONFile("Save", "HScore", runtimeScene, gdjs.VariablesContainer.badVariable);
}{for(var i = 0, len = gdjs.Main_95MenuCode.GDScoreObjects2.length ;i < len;++i) {
    gdjs.Main_95MenuCode.GDScoreObjects2[i].setString("" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("Score"))));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("HScore"), gdjs.Main_95MenuCode.GDHScoreObjects1);
{for(var i = 0, len = gdjs.Main_95MenuCode.GDHScoreObjects1.length ;i < len;++i) {
    gdjs.Main_95MenuCode.GDHScoreObjects1[i].setString("" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("HScore"))));
}
}}

}


};gdjs.Main_95MenuCode.eventsList2 = function(runtimeScene) {

{


gdjs.Main_95MenuCode.condition0IsTrue_0.val = false;
{
gdjs.Main_95MenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Main_95MenuCode.condition0IsTrue_0.val) {
{gdjs.adMob.setupBanner("ca-app-pub-9806557752529441/9321497882", "", false);
}{gdjs.adMob.showBanner();
}}

}


};gdjs.Main_95MenuCode.eventsList3 = function(runtimeScene) {

{


gdjs.Main_95MenuCode.eventsList0(runtimeScene);
}


{


gdjs.Main_95MenuCode.eventsList1(runtimeScene);
}


{


gdjs.Main_95MenuCode.eventsList2(runtimeScene);
}


};

gdjs.Main_95MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Main_95MenuCode.GDScoreObjects1.length = 0;
gdjs.Main_95MenuCode.GDScoreObjects2.length = 0;
gdjs.Main_95MenuCode.GDScoreObjects3.length = 0;
gdjs.Main_95MenuCode.GDPlayObjects1.length = 0;
gdjs.Main_95MenuCode.GDPlayObjects2.length = 0;
gdjs.Main_95MenuCode.GDPlayObjects3.length = 0;
gdjs.Main_95MenuCode.GDQuit_95GameObjects1.length = 0;
gdjs.Main_95MenuCode.GDQuit_95GameObjects2.length = 0;
gdjs.Main_95MenuCode.GDQuit_95GameObjects3.length = 0;
gdjs.Main_95MenuCode.GDPoints_95SystemObjects1.length = 0;
gdjs.Main_95MenuCode.GDPoints_95SystemObjects2.length = 0;
gdjs.Main_95MenuCode.GDPoints_95SystemObjects3.length = 0;
gdjs.Main_95MenuCode.GDPPTNCObjects1.length = 0;
gdjs.Main_95MenuCode.GDPPTNCObjects2.length = 0;
gdjs.Main_95MenuCode.GDPPTNCObjects3.length = 0;
gdjs.Main_95MenuCode.GDGuideObjects1.length = 0;
gdjs.Main_95MenuCode.GDGuideObjects2.length = 0;
gdjs.Main_95MenuCode.GDGuideObjects3.length = 0;
gdjs.Main_95MenuCode.GDYouTubeObjects1.length = 0;
gdjs.Main_95MenuCode.GDYouTubeObjects2.length = 0;
gdjs.Main_95MenuCode.GDYouTubeObjects3.length = 0;
gdjs.Main_95MenuCode.GDWebsiteObjects1.length = 0;
gdjs.Main_95MenuCode.GDWebsiteObjects2.length = 0;
gdjs.Main_95MenuCode.GDWebsiteObjects3.length = 0;
gdjs.Main_95MenuCode.GDMain_95MenuObjects1.length = 0;
gdjs.Main_95MenuCode.GDMain_95MenuObjects2.length = 0;
gdjs.Main_95MenuCode.GDMain_95MenuObjects3.length = 0;
gdjs.Main_95MenuCode.GDGuide1Objects1.length = 0;
gdjs.Main_95MenuCode.GDGuide1Objects2.length = 0;
gdjs.Main_95MenuCode.GDGuide1Objects3.length = 0;
gdjs.Main_95MenuCode.GDPPTNC1Objects1.length = 0;
gdjs.Main_95MenuCode.GDPPTNC1Objects2.length = 0;
gdjs.Main_95MenuCode.GDPPTNC1Objects3.length = 0;
gdjs.Main_95MenuCode.GDPlay2Objects1.length = 0;
gdjs.Main_95MenuCode.GDPlay2Objects2.length = 0;
gdjs.Main_95MenuCode.GDPlay2Objects3.length = 0;
gdjs.Main_95MenuCode.GDQuitObjects1.length = 0;
gdjs.Main_95MenuCode.GDQuitObjects2.length = 0;
gdjs.Main_95MenuCode.GDQuitObjects3.length = 0;
gdjs.Main_95MenuCode.GDHighScore1Objects1.length = 0;
gdjs.Main_95MenuCode.GDHighScore1Objects2.length = 0;
gdjs.Main_95MenuCode.GDHighScore1Objects3.length = 0;
gdjs.Main_95MenuCode.GDHScoreObjects1.length = 0;
gdjs.Main_95MenuCode.GDHScoreObjects2.length = 0;
gdjs.Main_95MenuCode.GDHScoreObjects3.length = 0;
gdjs.Main_95MenuCode.GDMain_95Menu1Objects1.length = 0;
gdjs.Main_95MenuCode.GDMain_95Menu1Objects2.length = 0;
gdjs.Main_95MenuCode.GDMain_95Menu1Objects3.length = 0;
gdjs.Main_95MenuCode.GDYTObjects1.length = 0;
gdjs.Main_95MenuCode.GDYTObjects2.length = 0;
gdjs.Main_95MenuCode.GDYTObjects3.length = 0;
gdjs.Main_95MenuCode.GDWebObjects1.length = 0;
gdjs.Main_95MenuCode.GDWebObjects2.length = 0;
gdjs.Main_95MenuCode.GDWebObjects3.length = 0;
gdjs.Main_95MenuCode.GDAveObjects1.length = 0;
gdjs.Main_95MenuCode.GDAveObjects2.length = 0;
gdjs.Main_95MenuCode.GDAveObjects3.length = 0;

gdjs.Main_95MenuCode.eventsList3(runtimeScene);
return;

}

gdjs['Main_95MenuCode'] = gdjs.Main_95MenuCode;
