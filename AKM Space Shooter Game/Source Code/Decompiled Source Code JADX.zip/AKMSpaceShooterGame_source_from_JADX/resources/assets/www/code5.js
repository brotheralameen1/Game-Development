gdjs.Game_95OverCode = {};
gdjs.Game_95OverCode.GDScoreObjects1= [];
gdjs.Game_95OverCode.GDScoreObjects2= [];
gdjs.Game_95OverCode.GDScoreObjects3= [];
gdjs.Game_95OverCode.GDGame_95OverObjects1= [];
gdjs.Game_95OverCode.GDGame_95OverObjects2= [];
gdjs.Game_95OverCode.GDGame_95OverObjects3= [];
gdjs.Game_95OverCode.GDGame_95Over1Objects1= [];
gdjs.Game_95OverCode.GDGame_95Over1Objects2= [];
gdjs.Game_95OverCode.GDGame_95Over1Objects3= [];
gdjs.Game_95OverCode.GDMain_95MenuObjects1= [];
gdjs.Game_95OverCode.GDMain_95MenuObjects2= [];
gdjs.Game_95OverCode.GDMain_95MenuObjects3= [];
gdjs.Game_95OverCode.GDMain_95Menu1Objects1= [];
gdjs.Game_95OverCode.GDMain_95Menu1Objects2= [];
gdjs.Game_95OverCode.GDMain_95Menu1Objects3= [];

gdjs.Game_95OverCode.conditionTrue_0 = {val:false};
gdjs.Game_95OverCode.condition0IsTrue_0 = {val:false};
gdjs.Game_95OverCode.condition1IsTrue_0 = {val:false};
gdjs.Game_95OverCode.condition2IsTrue_0 = {val:false};


gdjs.Game_95OverCode.mapOfGDgdjs_46Game_9595OverCode_46GDMain_9595MenuObjects2Objects = Hashtable.newFrom({"Main_Menu": gdjs.Game_95OverCode.GDMain_95MenuObjects2});gdjs.Game_95OverCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Main_Menu"), gdjs.Game_95OverCode.GDMain_95MenuObjects2);

gdjs.Game_95OverCode.condition0IsTrue_0.val = false;
gdjs.Game_95OverCode.condition1IsTrue_0.val = false;
{
gdjs.Game_95OverCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Game_95OverCode.mapOfGDgdjs_46Game_9595OverCode_46GDMain_9595MenuObjects2Objects, runtimeScene, true, false);
}if ( gdjs.Game_95OverCode.condition0IsTrue_0.val ) {
{
gdjs.Game_95OverCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.Game_95OverCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main_Menu", false);
}{gdjs.adMob.loadInterstitial("ca-app-pub-9806557752529441/1473947398", "", false);
}{gdjs.adMob.showInterstitial();
}}

}


{


{
}

}


};gdjs.Game_95OverCode.eventsList1 = function(runtimeScene) {

{


gdjs.Game_95OverCode.eventsList0(runtimeScene);
}


};

gdjs.Game_95OverCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_95OverCode.GDScoreObjects1.length = 0;
gdjs.Game_95OverCode.GDScoreObjects2.length = 0;
gdjs.Game_95OverCode.GDScoreObjects3.length = 0;
gdjs.Game_95OverCode.GDGame_95OverObjects1.length = 0;
gdjs.Game_95OverCode.GDGame_95OverObjects2.length = 0;
gdjs.Game_95OverCode.GDGame_95OverObjects3.length = 0;
gdjs.Game_95OverCode.GDGame_95Over1Objects1.length = 0;
gdjs.Game_95OverCode.GDGame_95Over1Objects2.length = 0;
gdjs.Game_95OverCode.GDGame_95Over1Objects3.length = 0;
gdjs.Game_95OverCode.GDMain_95MenuObjects1.length = 0;
gdjs.Game_95OverCode.GDMain_95MenuObjects2.length = 0;
gdjs.Game_95OverCode.GDMain_95MenuObjects3.length = 0;
gdjs.Game_95OverCode.GDMain_95Menu1Objects1.length = 0;
gdjs.Game_95OverCode.GDMain_95Menu1Objects2.length = 0;
gdjs.Game_95OverCode.GDMain_95Menu1Objects3.length = 0;

gdjs.Game_95OverCode.eventsList1(runtimeScene);
return;

}

gdjs['Game_95OverCode'] = gdjs.Game_95OverCode;
