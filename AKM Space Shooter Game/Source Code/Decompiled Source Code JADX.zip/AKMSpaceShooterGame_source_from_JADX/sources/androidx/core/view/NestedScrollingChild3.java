package androidx.core.view;

public interface NestedScrollingChild3 extends NestedScrollingChild2 {
    void dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr, int i5, int[] iArr2);
}
