gdjs.ContributeCode = {};
gdjs.ContributeCode.GDbackgroundObjects1= [];
gdjs.ContributeCode.GDbackgroundObjects2= [];
gdjs.ContributeCode.GDContribObjects1= [];
gdjs.ContributeCode.GDContribObjects2= [];
gdjs.ContributeCode.GDCryptoObjects1= [];
gdjs.ContributeCode.GDCryptoObjects2= [];
gdjs.ContributeCode.GDYouTubeObjects1= [];
gdjs.ContributeCode.GDYouTubeObjects2= [];
gdjs.ContributeCode.GDMain_9595MenuObjects1= [];
gdjs.ContributeCode.GDMain_9595MenuObjects2= [];
gdjs.ContributeCode.GDExitObjects1= [];
gdjs.ContributeCode.GDExitObjects2= [];
gdjs.ContributeCode.GDContrib1Objects1= [];
gdjs.ContributeCode.GDContrib1Objects2= [];
gdjs.ContributeCode.GDCrypto1Objects1= [];
gdjs.ContributeCode.GDCrypto1Objects2= [];
gdjs.ContributeCode.GDYouTube1Objects1= [];
gdjs.ContributeCode.GDYouTube1Objects2= [];
gdjs.ContributeCode.GDMain_9595Menu2Objects1= [];
gdjs.ContributeCode.GDMain_9595Menu2Objects2= [];
gdjs.ContributeCode.GDExit2Objects1= [];
gdjs.ContributeCode.GDExit2Objects2= [];


gdjs.ContributeCode.mapOfGDgdjs_9546ContributeCode_9546GDCryptoObjects1Objects = Hashtable.newFrom({"Crypto": gdjs.ContributeCode.GDCryptoObjects1});
gdjs.ContributeCode.mapOfGDgdjs_9546ContributeCode_9546GDCryptoObjects1Objects = Hashtable.newFrom({"Crypto": gdjs.ContributeCode.GDCryptoObjects1});
gdjs.ContributeCode.mapOfGDgdjs_9546ContributeCode_9546GDMain_95959595MenuObjects1Objects = Hashtable.newFrom({"Main_Menu": gdjs.ContributeCode.GDMain_9595MenuObjects1});
gdjs.ContributeCode.mapOfGDgdjs_9546ContributeCode_9546GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.ContributeCode.GDExitObjects1});
gdjs.ContributeCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Crypto"), gdjs.ContributeCode.GDCryptoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ContributeCode.mapOfGDgdjs_9546ContributeCode_9546GDCryptoObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://pastebin.com/hvswspz1", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Crypto"), gdjs.ContributeCode.GDCryptoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ContributeCode.mapOfGDgdjs_9546ContributeCode_9546GDCryptoObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://www.youtube.com/channel/UCRmZnjgfrD7al_h-cyOdQLA", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Main_Menu"), gdjs.ContributeCode.GDMain_9595MenuObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ContributeCode.mapOfGDgdjs_9546ContributeCode_9546GDMain_95959595MenuObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Start_Menu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.ContributeCode.GDExitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ContributeCode.mapOfGDgdjs_9546ContributeCode_9546GDExitObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.ContributeCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ContributeCode.GDbackgroundObjects1.length = 0;
gdjs.ContributeCode.GDbackgroundObjects2.length = 0;
gdjs.ContributeCode.GDContribObjects1.length = 0;
gdjs.ContributeCode.GDContribObjects2.length = 0;
gdjs.ContributeCode.GDCryptoObjects1.length = 0;
gdjs.ContributeCode.GDCryptoObjects2.length = 0;
gdjs.ContributeCode.GDYouTubeObjects1.length = 0;
gdjs.ContributeCode.GDYouTubeObjects2.length = 0;
gdjs.ContributeCode.GDMain_9595MenuObjects1.length = 0;
gdjs.ContributeCode.GDMain_9595MenuObjects2.length = 0;
gdjs.ContributeCode.GDExitObjects1.length = 0;
gdjs.ContributeCode.GDExitObjects2.length = 0;
gdjs.ContributeCode.GDContrib1Objects1.length = 0;
gdjs.ContributeCode.GDContrib1Objects2.length = 0;
gdjs.ContributeCode.GDCrypto1Objects1.length = 0;
gdjs.ContributeCode.GDCrypto1Objects2.length = 0;
gdjs.ContributeCode.GDYouTube1Objects1.length = 0;
gdjs.ContributeCode.GDYouTube1Objects2.length = 0;
gdjs.ContributeCode.GDMain_9595Menu2Objects1.length = 0;
gdjs.ContributeCode.GDMain_9595Menu2Objects2.length = 0;
gdjs.ContributeCode.GDExit2Objects1.length = 0;
gdjs.ContributeCode.GDExit2Objects2.length = 0;

gdjs.ContributeCode.eventsList0(runtimeScene);

return;

}

gdjs['ContributeCode'] = gdjs.ContributeCode;
