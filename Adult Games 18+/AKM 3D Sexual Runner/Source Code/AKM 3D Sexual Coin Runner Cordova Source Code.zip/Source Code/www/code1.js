gdjs.Start_95MenuCode = {};
gdjs.Start_95MenuCode.GDBackgroundObjects1= [];
gdjs.Start_95MenuCode.GDBackgroundObjects2= [];
gdjs.Start_95MenuCode.GDWelcomeObjects1= [];
gdjs.Start_95MenuCode.GDWelcomeObjects2= [];
gdjs.Start_95MenuCode.GDIntroObjects1= [];
gdjs.Start_95MenuCode.GDIntroObjects2= [];
gdjs.Start_95MenuCode.GDPlay_9595GameObjects1= [];
gdjs.Start_95MenuCode.GDPlay_9595GameObjects2= [];
gdjs.Start_95MenuCode.GDPlay_9595Game1Objects1= [];
gdjs.Start_95MenuCode.GDPlay_9595Game1Objects2= [];
gdjs.Start_95MenuCode.GDHow_9595ToObjects1= [];
gdjs.Start_95MenuCode.GDHow_9595ToObjects2= [];
gdjs.Start_95MenuCode.GDContribObjects1= [];
gdjs.Start_95MenuCode.GDContribObjects2= [];
gdjs.Start_95MenuCode.GDExitObjects1= [];
gdjs.Start_95MenuCode.GDExitObjects2= [];
gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects1= [];
gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects2= [];
gdjs.Start_95MenuCode.GDContrib2Objects1= [];
gdjs.Start_95MenuCode.GDContrib2Objects2= [];
gdjs.Start_95MenuCode.GDExit2Objects1= [];
gdjs.Start_95MenuCode.GDExit2Objects2= [];


gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDPlay_95959595GameObjects1Objects = Hashtable.newFrom({"Play_Game": gdjs.Start_95MenuCode.GDPlay_9595GameObjects1});
gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDHow_95959595ToObjects1Objects = Hashtable.newFrom({"How_To": gdjs.Start_95MenuCode.GDHow_9595ToObjects1});
gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDContribObjects1Objects = Hashtable.newFrom({"Contrib": gdjs.Start_95MenuCode.GDContribObjects1});
gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.Start_95MenuCode.GDExitObjects1});
gdjs.Start_95MenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Play_Game"), gdjs.Start_95MenuCode.GDPlay_9595GameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDPlay_95959595GameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("How_To"), gdjs.Start_95MenuCode.GDHow_9595ToObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDHow_95959595ToObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "How_To_Play", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Contrib"), gdjs.Start_95MenuCode.GDContribObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDContribObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Contribute", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.Start_95MenuCode.GDExitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDExitObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


};

gdjs.Start_95MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Start_95MenuCode.GDBackgroundObjects1.length = 0;
gdjs.Start_95MenuCode.GDBackgroundObjects2.length = 0;
gdjs.Start_95MenuCode.GDWelcomeObjects1.length = 0;
gdjs.Start_95MenuCode.GDWelcomeObjects2.length = 0;
gdjs.Start_95MenuCode.GDIntroObjects1.length = 0;
gdjs.Start_95MenuCode.GDIntroObjects2.length = 0;
gdjs.Start_95MenuCode.GDPlay_9595GameObjects1.length = 0;
gdjs.Start_95MenuCode.GDPlay_9595GameObjects2.length = 0;
gdjs.Start_95MenuCode.GDPlay_9595Game1Objects1.length = 0;
gdjs.Start_95MenuCode.GDPlay_9595Game1Objects2.length = 0;
gdjs.Start_95MenuCode.GDHow_9595ToObjects1.length = 0;
gdjs.Start_95MenuCode.GDHow_9595ToObjects2.length = 0;
gdjs.Start_95MenuCode.GDContribObjects1.length = 0;
gdjs.Start_95MenuCode.GDContribObjects2.length = 0;
gdjs.Start_95MenuCode.GDExitObjects1.length = 0;
gdjs.Start_95MenuCode.GDExitObjects2.length = 0;
gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects1.length = 0;
gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects2.length = 0;
gdjs.Start_95MenuCode.GDContrib2Objects1.length = 0;
gdjs.Start_95MenuCode.GDContrib2Objects2.length = 0;
gdjs.Start_95MenuCode.GDExit2Objects1.length = 0;
gdjs.Start_95MenuCode.GDExit2Objects2.length = 0;

gdjs.Start_95MenuCode.eventsList0(runtimeScene);

return;

}

gdjs['Start_95MenuCode'] = gdjs.Start_95MenuCode;
