gdjs.SexualityCode = {};
gdjs.SexualityCode.GDBackgroundObjects1= [];
gdjs.SexualityCode.GDBackgroundObjects2= [];
gdjs.SexualityCode.GDBackground1Objects1= [];
gdjs.SexualityCode.GDBackground1Objects2= [];
gdjs.SexualityCode.GDBackground2Objects1= [];
gdjs.SexualityCode.GDBackground2Objects2= [];
gdjs.SexualityCode.GDChooseObjects1= [];
gdjs.SexualityCode.GDChooseObjects2= [];
gdjs.SexualityCode.GDLesbianObjects1= [];
gdjs.SexualityCode.GDLesbianObjects2= [];
gdjs.SexualityCode.GDGayObjects1= [];
gdjs.SexualityCode.GDGayObjects2= [];
gdjs.SexualityCode.GDStraightObjects1= [];
gdjs.SexualityCode.GDStraightObjects2= [];
gdjs.SexualityCode.GDTransgenderObjects1= [];
gdjs.SexualityCode.GDTransgenderObjects2= [];
gdjs.SexualityCode.GDImpDescrObjects1= [];
gdjs.SexualityCode.GDImpDescrObjects2= [];
gdjs.SexualityCode.GDChoose2Objects1= [];
gdjs.SexualityCode.GDChoose2Objects2= [];
gdjs.SexualityCode.GDStraight2Objects1= [];
gdjs.SexualityCode.GDStraight2Objects2= [];
gdjs.SexualityCode.GDLesboObjects1= [];
gdjs.SexualityCode.GDLesboObjects2= [];
gdjs.SexualityCode.GDGay2Objects1= [];
gdjs.SexualityCode.GDGay2Objects2= [];
gdjs.SexualityCode.GDTransgender2Objects1= [];
gdjs.SexualityCode.GDTransgender2Objects2= [];
gdjs.SexualityCode.GDNo_9595TurnObjects1= [];
gdjs.SexualityCode.GDNo_9595TurnObjects2= [];


gdjs.SexualityCode.mapOfGDgdjs_9546SexualityCode_9546GDLesbianObjects1Objects = Hashtable.newFrom({"Lesbian": gdjs.SexualityCode.GDLesbianObjects1});
gdjs.SexualityCode.mapOfGDgdjs_9546SexualityCode_9546GDGayObjects1Objects = Hashtable.newFrom({"Gay": gdjs.SexualityCode.GDGayObjects1});
gdjs.SexualityCode.mapOfGDgdjs_9546SexualityCode_9546GDStraightObjects1Objects = Hashtable.newFrom({"Straight": gdjs.SexualityCode.GDStraightObjects1});
gdjs.SexualityCode.mapOfGDgdjs_9546SexualityCode_9546GDTransgenderObjects1Objects = Hashtable.newFrom({"Transgender": gdjs.SexualityCode.GDTransgenderObjects1});
gdjs.SexualityCode.eventsList0 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Lesbian"), gdjs.SexualityCode.GDLesbianObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.SexualityCode.mapOfGDgdjs_9546SexualityCode_9546GDLesbianObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Lesbian1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gay"), gdjs.SexualityCode.GDGayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.SexualityCode.mapOfGDgdjs_9546SexualityCode_9546GDGayObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Gay1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Straight"), gdjs.SexualityCode.GDStraightObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.SexualityCode.mapOfGDgdjs_9546SexualityCode_9546GDStraightObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Straight1", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Transgender"), gdjs.SexualityCode.GDTransgenderObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.SexualityCode.mapOfGDgdjs_9546SexualityCode_9546GDTransgenderObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Transgender1", false);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.SexualityCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.SexualityCode.GDBackgroundObjects1.length = 0;
gdjs.SexualityCode.GDBackgroundObjects2.length = 0;
gdjs.SexualityCode.GDBackground1Objects1.length = 0;
gdjs.SexualityCode.GDBackground1Objects2.length = 0;
gdjs.SexualityCode.GDBackground2Objects1.length = 0;
gdjs.SexualityCode.GDBackground2Objects2.length = 0;
gdjs.SexualityCode.GDChooseObjects1.length = 0;
gdjs.SexualityCode.GDChooseObjects2.length = 0;
gdjs.SexualityCode.GDLesbianObjects1.length = 0;
gdjs.SexualityCode.GDLesbianObjects2.length = 0;
gdjs.SexualityCode.GDGayObjects1.length = 0;
gdjs.SexualityCode.GDGayObjects2.length = 0;
gdjs.SexualityCode.GDStraightObjects1.length = 0;
gdjs.SexualityCode.GDStraightObjects2.length = 0;
gdjs.SexualityCode.GDTransgenderObjects1.length = 0;
gdjs.SexualityCode.GDTransgenderObjects2.length = 0;
gdjs.SexualityCode.GDImpDescrObjects1.length = 0;
gdjs.SexualityCode.GDImpDescrObjects2.length = 0;
gdjs.SexualityCode.GDChoose2Objects1.length = 0;
gdjs.SexualityCode.GDChoose2Objects2.length = 0;
gdjs.SexualityCode.GDStraight2Objects1.length = 0;
gdjs.SexualityCode.GDStraight2Objects2.length = 0;
gdjs.SexualityCode.GDLesboObjects1.length = 0;
gdjs.SexualityCode.GDLesboObjects2.length = 0;
gdjs.SexualityCode.GDGay2Objects1.length = 0;
gdjs.SexualityCode.GDGay2Objects2.length = 0;
gdjs.SexualityCode.GDTransgender2Objects1.length = 0;
gdjs.SexualityCode.GDTransgender2Objects2.length = 0;
gdjs.SexualityCode.GDNo_9595TurnObjects1.length = 0;
gdjs.SexualityCode.GDNo_9595TurnObjects2.length = 0;

gdjs.SexualityCode.eventsList0(runtimeScene);

return;

}

gdjs['SexualityCode'] = gdjs.SexualityCode;
