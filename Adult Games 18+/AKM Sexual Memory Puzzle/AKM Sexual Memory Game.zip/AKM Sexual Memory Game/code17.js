gdjs.CongratulationsCode = {};
gdjs.CongratulationsCode.GDBackgroundObjects1= [];
gdjs.CongratulationsCode.GDBackgroundObjects2= [];
gdjs.CongratulationsCode.GDCongratulationsObjects1= [];
gdjs.CongratulationsCode.GDCongratulationsObjects2= [];
gdjs.CongratulationsCode.GDInformationObjects1= [];
gdjs.CongratulationsCode.GDInformationObjects2= [];
gdjs.CongratulationsCode.GDMain_9595MenuObjects1= [];
gdjs.CongratulationsCode.GDMain_9595MenuObjects2= [];
gdjs.CongratulationsCode.GDPlay_9595AgainObjects1= [];
gdjs.CongratulationsCode.GDPlay_9595AgainObjects2= [];
gdjs.CongratulationsCode.GDExitObjects1= [];
gdjs.CongratulationsCode.GDExitObjects2= [];
gdjs.CongratulationsCode.GDCongratsObjects1= [];
gdjs.CongratulationsCode.GDCongratsObjects2= [];
gdjs.CongratulationsCode.GDInfoObjects1= [];
gdjs.CongratulationsCode.GDInfoObjects2= [];
gdjs.CongratulationsCode.GDExit2Objects1= [];
gdjs.CongratulationsCode.GDExit2Objects2= [];
gdjs.CongratulationsCode.GDPlay_9595AGainObjects1= [];
gdjs.CongratulationsCode.GDPlay_9595AGainObjects2= [];
gdjs.CongratulationsCode.GDMain_9595Menu2Objects1= [];
gdjs.CongratulationsCode.GDMain_9595Menu2Objects2= [];


gdjs.CongratulationsCode.mapOfGDgdjs_9546CongratulationsCode_9546GDMain_95959595MenuObjects1Objects = Hashtable.newFrom({"Main_Menu": gdjs.CongratulationsCode.GDMain_9595MenuObjects1});
gdjs.CongratulationsCode.mapOfGDgdjs_9546CongratulationsCode_9546GDPlay_95959595AgainObjects1Objects = Hashtable.newFrom({"Play_Again": gdjs.CongratulationsCode.GDPlay_9595AgainObjects1});
gdjs.CongratulationsCode.mapOfGDgdjs_9546CongratulationsCode_9546GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.CongratulationsCode.GDExitObjects1});
gdjs.CongratulationsCode.eventsList0 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Main_Menu"), gdjs.CongratulationsCode.GDMain_9595MenuObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CongratulationsCode.mapOfGDgdjs_9546CongratulationsCode_9546GDMain_95959595MenuObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Start_Menu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Play_Again"), gdjs.CongratulationsCode.GDPlay_9595AgainObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CongratulationsCode.mapOfGDgdjs_9546CongratulationsCode_9546GDPlay_95959595AgainObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Sexuality", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.CongratulationsCode.GDExitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.CongratulationsCode.mapOfGDgdjs_9546CongratulationsCode_9546GDExitObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


};

gdjs.CongratulationsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.CongratulationsCode.GDBackgroundObjects1.length = 0;
gdjs.CongratulationsCode.GDBackgroundObjects2.length = 0;
gdjs.CongratulationsCode.GDCongratulationsObjects1.length = 0;
gdjs.CongratulationsCode.GDCongratulationsObjects2.length = 0;
gdjs.CongratulationsCode.GDInformationObjects1.length = 0;
gdjs.CongratulationsCode.GDInformationObjects2.length = 0;
gdjs.CongratulationsCode.GDMain_9595MenuObjects1.length = 0;
gdjs.CongratulationsCode.GDMain_9595MenuObjects2.length = 0;
gdjs.CongratulationsCode.GDPlay_9595AgainObjects1.length = 0;
gdjs.CongratulationsCode.GDPlay_9595AgainObjects2.length = 0;
gdjs.CongratulationsCode.GDExitObjects1.length = 0;
gdjs.CongratulationsCode.GDExitObjects2.length = 0;
gdjs.CongratulationsCode.GDCongratsObjects1.length = 0;
gdjs.CongratulationsCode.GDCongratsObjects2.length = 0;
gdjs.CongratulationsCode.GDInfoObjects1.length = 0;
gdjs.CongratulationsCode.GDInfoObjects2.length = 0;
gdjs.CongratulationsCode.GDExit2Objects1.length = 0;
gdjs.CongratulationsCode.GDExit2Objects2.length = 0;
gdjs.CongratulationsCode.GDPlay_9595AGainObjects1.length = 0;
gdjs.CongratulationsCode.GDPlay_9595AGainObjects2.length = 0;
gdjs.CongratulationsCode.GDMain_9595Menu2Objects1.length = 0;
gdjs.CongratulationsCode.GDMain_9595Menu2Objects2.length = 0;

gdjs.CongratulationsCode.eventsList0(runtimeScene);

return;

}

gdjs['CongratulationsCode'] = gdjs.CongratulationsCode;
