gdjs.DevSuppCode = {};
gdjs.DevSuppCode.GDDescObjects1= [];
gdjs.DevSuppCode.GDDescObjects2= [];
gdjs.DevSuppCode.GDBackgroundObjects1= [];
gdjs.DevSuppCode.GDBackgroundObjects2= [];
gdjs.DevSuppCode.GDYouTubeObjects1= [];
gdjs.DevSuppCode.GDYouTubeObjects2= [];
gdjs.DevSuppCode.GDCryptoObjects1= [];
gdjs.DevSuppCode.GDCryptoObjects2= [];
gdjs.DevSuppCode.GDBackObjects1= [];
gdjs.DevSuppCode.GDBackObjects2= [];
gdjs.DevSuppCode.GDQuitObjects1= [];
gdjs.DevSuppCode.GDQuitObjects2= [];
gdjs.DevSuppCode.GDInfoObjects1= [];
gdjs.DevSuppCode.GDInfoObjects2= [];
gdjs.DevSuppCode.GDDevSupp1Objects1= [];
gdjs.DevSuppCode.GDDevSupp1Objects2= [];
gdjs.DevSuppCode.GDTheFleshObjects1= [];
gdjs.DevSuppCode.GDTheFleshObjects2= [];
gdjs.DevSuppCode.GDYouTube2Objects1= [];
gdjs.DevSuppCode.GDYouTube2Objects2= [];
gdjs.DevSuppCode.GDCrypto2Objects1= [];
gdjs.DevSuppCode.GDCrypto2Objects2= [];
gdjs.DevSuppCode.GDBack2Objects1= [];
gdjs.DevSuppCode.GDBack2Objects2= [];
gdjs.DevSuppCode.GDQuit2Objects1= [];
gdjs.DevSuppCode.GDQuit2Objects2= [];


gdjs.DevSuppCode.mapOfGDgdjs_9546DevSuppCode_9546GDCryptoObjects1Objects = Hashtable.newFrom({"Crypto": gdjs.DevSuppCode.GDCryptoObjects1});
gdjs.DevSuppCode.mapOfGDgdjs_9546DevSuppCode_9546GDYouTubeObjects1Objects = Hashtable.newFrom({"YouTube": gdjs.DevSuppCode.GDYouTubeObjects1});
gdjs.DevSuppCode.mapOfGDgdjs_9546DevSuppCode_9546GDBackObjects1Objects = Hashtable.newFrom({"Back": gdjs.DevSuppCode.GDBackObjects1});
gdjs.DevSuppCode.mapOfGDgdjs_9546DevSuppCode_9546GDQuitObjects1Objects = Hashtable.newFrom({"Quit": gdjs.DevSuppCode.GDQuitObjects1});
gdjs.DevSuppCode.eventsList0 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Crypto"), gdjs.DevSuppCode.GDCryptoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.DevSuppCode.mapOfGDgdjs_9546DevSuppCode_9546GDCryptoObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://pastebin.com/hvswspz1", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("YouTube"), gdjs.DevSuppCode.GDYouTubeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.DevSuppCode.mapOfGDgdjs_9546DevSuppCode_9546GDYouTubeObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://youtube.com/channel/UCRmZnjgfrD7al_h-cyOdQLA", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.DevSuppCode.GDBackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.DevSuppCode.mapOfGDgdjs_9546DevSuppCode_9546GDBackObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Start_Menu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quit"), gdjs.DevSuppCode.GDQuitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.DevSuppCode.mapOfGDgdjs_9546DevSuppCode_9546GDQuitObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.DevSuppCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.DevSuppCode.GDDescObjects1.length = 0;
gdjs.DevSuppCode.GDDescObjects2.length = 0;
gdjs.DevSuppCode.GDBackgroundObjects1.length = 0;
gdjs.DevSuppCode.GDBackgroundObjects2.length = 0;
gdjs.DevSuppCode.GDYouTubeObjects1.length = 0;
gdjs.DevSuppCode.GDYouTubeObjects2.length = 0;
gdjs.DevSuppCode.GDCryptoObjects1.length = 0;
gdjs.DevSuppCode.GDCryptoObjects2.length = 0;
gdjs.DevSuppCode.GDBackObjects1.length = 0;
gdjs.DevSuppCode.GDBackObjects2.length = 0;
gdjs.DevSuppCode.GDQuitObjects1.length = 0;
gdjs.DevSuppCode.GDQuitObjects2.length = 0;
gdjs.DevSuppCode.GDInfoObjects1.length = 0;
gdjs.DevSuppCode.GDInfoObjects2.length = 0;
gdjs.DevSuppCode.GDDevSupp1Objects1.length = 0;
gdjs.DevSuppCode.GDDevSupp1Objects2.length = 0;
gdjs.DevSuppCode.GDTheFleshObjects1.length = 0;
gdjs.DevSuppCode.GDTheFleshObjects2.length = 0;
gdjs.DevSuppCode.GDYouTube2Objects1.length = 0;
gdjs.DevSuppCode.GDYouTube2Objects2.length = 0;
gdjs.DevSuppCode.GDCrypto2Objects1.length = 0;
gdjs.DevSuppCode.GDCrypto2Objects2.length = 0;
gdjs.DevSuppCode.GDBack2Objects1.length = 0;
gdjs.DevSuppCode.GDBack2Objects2.length = 0;
gdjs.DevSuppCode.GDQuit2Objects1.length = 0;
gdjs.DevSuppCode.GDQuit2Objects2.length = 0;

gdjs.DevSuppCode.eventsList0(runtimeScene);

return;

}

gdjs['DevSuppCode'] = gdjs.DevSuppCode;
