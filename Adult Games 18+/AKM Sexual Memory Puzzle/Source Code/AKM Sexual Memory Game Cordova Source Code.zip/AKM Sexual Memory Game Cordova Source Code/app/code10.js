gdjs.Gay2Code = {};
gdjs.Gay2Code.forEachCount0_5 = 0;

gdjs.Gay2Code.forEachCount1_5 = 0;

gdjs.Gay2Code.forEachCount2_5 = 0;

gdjs.Gay2Code.forEachCount3_5 = 0;

gdjs.Gay2Code.forEachCount4_5 = 0;

gdjs.Gay2Code.forEachCount5_5 = 0;

gdjs.Gay2Code.forEachCount6_5 = 0;

gdjs.Gay2Code.forEachCount7_5 = 0;

gdjs.Gay2Code.forEachIndex3 = 0;

gdjs.Gay2Code.forEachIndex5 = 0;

gdjs.Gay2Code.forEachObjects3 = [];

gdjs.Gay2Code.forEachObjects5 = [];

gdjs.Gay2Code.forEachTemporary3 = null;

gdjs.Gay2Code.forEachTotalCount3 = 0;

gdjs.Gay2Code.forEachTotalCount5 = 0;

gdjs.Gay2Code.GDcard_9595crabObjects1= [];
gdjs.Gay2Code.GDcard_9595crabObjects2= [];
gdjs.Gay2Code.GDcard_9595crabObjects3= [];
gdjs.Gay2Code.GDcard_9595crabObjects4= [];
gdjs.Gay2Code.GDcard_9595crabObjects5= [];
gdjs.Gay2Code.GDcard_9595crabObjects6= [];
gdjs.Gay2Code.GDcard_9595crabObjects7= [];
gdjs.Gay2Code.GDcard_9595seahorseObjects1= [];
gdjs.Gay2Code.GDcard_9595seahorseObjects2= [];
gdjs.Gay2Code.GDcard_9595seahorseObjects3= [];
gdjs.Gay2Code.GDcard_9595seahorseObjects4= [];
gdjs.Gay2Code.GDcard_9595seahorseObjects5= [];
gdjs.Gay2Code.GDcard_9595seahorseObjects6= [];
gdjs.Gay2Code.GDcard_9595seahorseObjects7= [];
gdjs.Gay2Code.GDcard_9595snailObjects1= [];
gdjs.Gay2Code.GDcard_9595snailObjects2= [];
gdjs.Gay2Code.GDcard_9595snailObjects3= [];
gdjs.Gay2Code.GDcard_9595snailObjects4= [];
gdjs.Gay2Code.GDcard_9595snailObjects5= [];
gdjs.Gay2Code.GDcard_9595snailObjects6= [];
gdjs.Gay2Code.GDcard_9595snailObjects7= [];
gdjs.Gay2Code.GDcard_9595seagrassObjects1= [];
gdjs.Gay2Code.GDcard_9595seagrassObjects2= [];
gdjs.Gay2Code.GDcard_9595seagrassObjects3= [];
gdjs.Gay2Code.GDcard_9595seagrassObjects4= [];
gdjs.Gay2Code.GDcard_9595seagrassObjects5= [];
gdjs.Gay2Code.GDcard_9595seagrassObjects6= [];
gdjs.Gay2Code.GDcard_9595seagrassObjects7= [];
gdjs.Gay2Code.GDcard_9595coralObjects1= [];
gdjs.Gay2Code.GDcard_9595coralObjects2= [];
gdjs.Gay2Code.GDcard_9595coralObjects3= [];
gdjs.Gay2Code.GDcard_9595coralObjects4= [];
gdjs.Gay2Code.GDcard_9595coralObjects5= [];
gdjs.Gay2Code.GDcard_9595coralObjects6= [];
gdjs.Gay2Code.GDcard_9595coralObjects7= [];
gdjs.Gay2Code.GDcard_9595anemoneObjects1= [];
gdjs.Gay2Code.GDcard_9595anemoneObjects2= [];
gdjs.Gay2Code.GDcard_9595anemoneObjects3= [];
gdjs.Gay2Code.GDcard_9595anemoneObjects4= [];
gdjs.Gay2Code.GDcard_9595anemoneObjects5= [];
gdjs.Gay2Code.GDcard_9595anemoneObjects6= [];
gdjs.Gay2Code.GDcard_9595anemoneObjects7= [];
gdjs.Gay2Code.GDcard_9595plasticbagObjects1= [];
gdjs.Gay2Code.GDcard_9595plasticbagObjects2= [];
gdjs.Gay2Code.GDcard_9595plasticbagObjects3= [];
gdjs.Gay2Code.GDcard_9595plasticbagObjects4= [];
gdjs.Gay2Code.GDcard_9595plasticbagObjects5= [];
gdjs.Gay2Code.GDcard_9595plasticbagObjects6= [];
gdjs.Gay2Code.GDcard_9595plasticbagObjects7= [];
gdjs.Gay2Code.GDcard_9595blowfishObjects1= [];
gdjs.Gay2Code.GDcard_9595blowfishObjects2= [];
gdjs.Gay2Code.GDcard_9595blowfishObjects3= [];
gdjs.Gay2Code.GDcard_9595blowfishObjects4= [];
gdjs.Gay2Code.GDcard_9595blowfishObjects5= [];
gdjs.Gay2Code.GDcard_9595blowfishObjects6= [];
gdjs.Gay2Code.GDcard_9595blowfishObjects7= [];
gdjs.Gay2Code.GDposition_9595placeholderObjects1= [];
gdjs.Gay2Code.GDposition_9595placeholderObjects2= [];
gdjs.Gay2Code.GDposition_9595placeholderObjects3= [];
gdjs.Gay2Code.GDposition_9595placeholderObjects4= [];
gdjs.Gay2Code.GDposition_9595placeholderObjects5= [];
gdjs.Gay2Code.GDposition_9595placeholderObjects6= [];
gdjs.Gay2Code.GDposition_9595placeholderObjects7= [];
gdjs.Gay2Code.GDnewgame_9595buttonObjects1= [];
gdjs.Gay2Code.GDnewgame_9595buttonObjects2= [];
gdjs.Gay2Code.GDnewgame_9595buttonObjects3= [];
gdjs.Gay2Code.GDnewgame_9595buttonObjects4= [];
gdjs.Gay2Code.GDnewgame_9595buttonObjects5= [];
gdjs.Gay2Code.GDnewgame_9595buttonObjects6= [];
gdjs.Gay2Code.GDnewgame_9595buttonObjects7= [];
gdjs.Gay2Code.GDboardObjects1= [];
gdjs.Gay2Code.GDboardObjects2= [];
gdjs.Gay2Code.GDboardObjects3= [];
gdjs.Gay2Code.GDboardObjects4= [];
gdjs.Gay2Code.GDboardObjects5= [];
gdjs.Gay2Code.GDboardObjects6= [];
gdjs.Gay2Code.GDboardObjects7= [];
gdjs.Gay2Code.GDpairsObjects1= [];
gdjs.Gay2Code.GDpairsObjects2= [];
gdjs.Gay2Code.GDpairsObjects3= [];
gdjs.Gay2Code.GDpairsObjects4= [];
gdjs.Gay2Code.GDpairsObjects5= [];
gdjs.Gay2Code.GDpairsObjects6= [];
gdjs.Gay2Code.GDpairsObjects7= [];
gdjs.Gay2Code.GDnewgameObjects1= [];
gdjs.Gay2Code.GDnewgameObjects2= [];
gdjs.Gay2Code.GDnewgameObjects3= [];
gdjs.Gay2Code.GDnewgameObjects4= [];
gdjs.Gay2Code.GDnewgameObjects5= [];
gdjs.Gay2Code.GDnewgameObjects6= [];
gdjs.Gay2Code.GDnewgameObjects7= [];
gdjs.Gay2Code.GDyouwonObjects1= [];
gdjs.Gay2Code.GDyouwonObjects2= [];
gdjs.Gay2Code.GDyouwonObjects3= [];
gdjs.Gay2Code.GDyouwonObjects4= [];
gdjs.Gay2Code.GDyouwonObjects5= [];
gdjs.Gay2Code.GDyouwonObjects6= [];
gdjs.Gay2Code.GDyouwonObjects7= [];
gdjs.Gay2Code.GDstar_9595particleObjects1= [];
gdjs.Gay2Code.GDstar_9595particleObjects2= [];
gdjs.Gay2Code.GDstar_9595particleObjects3= [];
gdjs.Gay2Code.GDstar_9595particleObjects4= [];
gdjs.Gay2Code.GDstar_9595particleObjects5= [];
gdjs.Gay2Code.GDstar_9595particleObjects6= [];
gdjs.Gay2Code.GDstar_9595particleObjects7= [];
gdjs.Gay2Code.GDscreen_9595fadeObjects1= [];
gdjs.Gay2Code.GDscreen_9595fadeObjects2= [];
gdjs.Gay2Code.GDscreen_9595fadeObjects3= [];
gdjs.Gay2Code.GDscreen_9595fadeObjects4= [];
gdjs.Gay2Code.GDscreen_9595fadeObjects5= [];
gdjs.Gay2Code.GDscreen_9595fadeObjects6= [];
gdjs.Gay2Code.GDscreen_9595fadeObjects7= [];
gdjs.Gay2Code.GDui_9595backgroundObjects1= [];
gdjs.Gay2Code.GDui_9595backgroundObjects2= [];
gdjs.Gay2Code.GDui_9595backgroundObjects3= [];
gdjs.Gay2Code.GDui_9595backgroundObjects4= [];
gdjs.Gay2Code.GDui_9595backgroundObjects5= [];
gdjs.Gay2Code.GDui_9595backgroundObjects6= [];
gdjs.Gay2Code.GDui_9595backgroundObjects7= [];
gdjs.Gay2Code.GDbackgroundObjects1= [];
gdjs.Gay2Code.GDbackgroundObjects2= [];
gdjs.Gay2Code.GDbackgroundObjects3= [];
gdjs.Gay2Code.GDbackgroundObjects4= [];
gdjs.Gay2Code.GDbackgroundObjects5= [];
gdjs.Gay2Code.GDbackgroundObjects6= [];
gdjs.Gay2Code.GDbackgroundObjects7= [];
gdjs.Gay2Code.GDrepeatObjects1= [];
gdjs.Gay2Code.GDrepeatObjects2= [];
gdjs.Gay2Code.GDrepeatObjects3= [];
gdjs.Gay2Code.GDrepeatObjects4= [];
gdjs.Gay2Code.GDrepeatObjects5= [];
gdjs.Gay2Code.GDrepeatObjects6= [];
gdjs.Gay2Code.GDrepeatObjects7= [];
gdjs.Gay2Code.GDSigilObjects1= [];
gdjs.Gay2Code.GDSigilObjects2= [];
gdjs.Gay2Code.GDSigilObjects3= [];
gdjs.Gay2Code.GDSigilObjects4= [];
gdjs.Gay2Code.GDSigilObjects5= [];
gdjs.Gay2Code.GDSigilObjects6= [];
gdjs.Gay2Code.GDSigilObjects7= [];


gdjs.Gay2Code.mapOfGDgdjs_9546Gay2Code_9546GDcard_95959595blowfishObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595crabObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595seahorseObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595snailObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595seagrassObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595coralObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595anemoneObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595plasticbagObjects4Objects = Hashtable.newFrom({"card_blowfish": gdjs.Gay2Code.GDcard_9595blowfishObjects4, "card_crab": gdjs.Gay2Code.GDcard_9595crabObjects4, "card_seahorse": gdjs.Gay2Code.GDcard_9595seahorseObjects4, "card_snail": gdjs.Gay2Code.GDcard_9595snailObjects4, "card_seagrass": gdjs.Gay2Code.GDcard_9595seagrassObjects4, "card_coral": gdjs.Gay2Code.GDcard_9595coralObjects4, "card_anemone": gdjs.Gay2Code.GDcard_9595anemoneObjects4, "card_plasticbag": gdjs.Gay2Code.GDcard_9595plasticbagObjects4});
gdjs.Gay2Code.eventsList0 = function(runtimeScene) {

{

/* Reuse gdjs.Gay2Code.GDcard_9595anemoneObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595blowfishObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595coralObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595crabObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595plasticbagObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595seagrassObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595seahorseObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595snailObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gay2Code.mapOfGDgdjs_9546Gay2Code_9546GDcard_95959595blowfishObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595crabObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595seahorseObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595snailObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595seagrassObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595coralObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595anemoneObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595plasticbagObjects4Objects);
if (isConditionTrue_0) {
/* Reuse gdjs.Gay2Code.GDcard_9595anemoneObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595blowfishObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595coralObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595crabObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595plasticbagObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595seagrassObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595seahorseObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595snailObjects4 */
/* Reuse gdjs.Gay2Code.GDposition_9595placeholderObjects4 */
{for(var i = 0, len = gdjs.Gay2Code.GDcard_9595blowfishObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595blowfishObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595crabObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595crabObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seahorseObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seahorseObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595snailObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595snailObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seagrassObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seagrassObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595coralObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595coralObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595anemoneObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595anemoneObjects4[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595plasticbagObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595plasticbagObjects4[i].setAnimationName("back");
}
}{for(var i = 0, len = gdjs.Gay2Code.GDposition_9595placeholderObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDposition_9595placeholderObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Gay2Code.eventsList1 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("card_anemone"), gdjs.Gay2Code.GDcard_9595anemoneObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish"), gdjs.Gay2Code.GDcard_9595blowfishObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_coral"), gdjs.Gay2Code.GDcard_9595coralObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_crab"), gdjs.Gay2Code.GDcard_9595crabObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag"), gdjs.Gay2Code.GDcard_9595plasticbagObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass"), gdjs.Gay2Code.GDcard_9595seagrassObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse"), gdjs.Gay2Code.GDcard_9595seahorseObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_snail"), gdjs.Gay2Code.GDcard_9595snailObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595blowfishObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595blowfishObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595blowfishObjects4[k] = gdjs.Gay2Code.GDcard_9595blowfishObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595blowfishObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595crabObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595crabObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595crabObjects4[k] = gdjs.Gay2Code.GDcard_9595crabObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595crabObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595seahorseObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595seahorseObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595seahorseObjects4[k] = gdjs.Gay2Code.GDcard_9595seahorseObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595seahorseObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595snailObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595snailObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595snailObjects4[k] = gdjs.Gay2Code.GDcard_9595snailObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595snailObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595seagrassObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595seagrassObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595seagrassObjects4[k] = gdjs.Gay2Code.GDcard_9595seagrassObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595seagrassObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595coralObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595coralObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595coralObjects4[k] = gdjs.Gay2Code.GDcard_9595coralObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595coralObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595anemoneObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595anemoneObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595anemoneObjects4[k] = gdjs.Gay2Code.GDcard_9595anemoneObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595anemoneObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595plasticbagObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595plasticbagObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595plasticbagObjects4[k] = gdjs.Gay2Code.GDcard_9595plasticbagObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595plasticbagObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Gay2Code.GDcard_9595anemoneObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595blowfishObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595coralObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595crabObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595plasticbagObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595seagrassObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595seahorseObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595snailObjects4 */
gdjs.copyArray(gdjs.Gay2Code.GDposition_9595placeholderObjects3, gdjs.Gay2Code.GDposition_9595placeholderObjects4);

{for(var i = 0, len = gdjs.Gay2Code.GDcard_9595blowfishObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595blowfishObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Gay2Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Gay2Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Gay2Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Gay2Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595crabObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595crabObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Gay2Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Gay2Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Gay2Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Gay2Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seahorseObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seahorseObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Gay2Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Gay2Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Gay2Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Gay2Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595snailObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595snailObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Gay2Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Gay2Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Gay2Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Gay2Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seagrassObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seagrassObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Gay2Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Gay2Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Gay2Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Gay2Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595coralObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595coralObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Gay2Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Gay2Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Gay2Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Gay2Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595anemoneObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595anemoneObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Gay2Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Gay2Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Gay2Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Gay2Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595plasticbagObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595plasticbagObjects4[i].getBehavior("Tween").addObjectPositionTween("fly_in", (( gdjs.Gay2Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Gay2Code.GDposition_9595placeholderObjects4[0].getPointX("")), (( gdjs.Gay2Code.GDposition_9595placeholderObjects4.length === 0 ) ? 0 :gdjs.Gay2Code.GDposition_9595placeholderObjects4[0].getPointY("")), "easeOutSine", 1000, false);
}
}
{ //Subevents
gdjs.Gay2Code.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.Gay2Code.eventsList2 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "show_cards");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "show_cards");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("position_placeholder"), gdjs.Gay2Code.GDposition_9595placeholderObjects2);

for (gdjs.Gay2Code.forEachIndex3 = 0;gdjs.Gay2Code.forEachIndex3 < gdjs.Gay2Code.GDposition_9595placeholderObjects2.length;++gdjs.Gay2Code.forEachIndex3) {
gdjs.Gay2Code.GDposition_9595placeholderObjects3.length = 0;


gdjs.Gay2Code.forEachTemporary3 = gdjs.Gay2Code.GDposition_9595placeholderObjects2[gdjs.Gay2Code.forEachIndex3];
gdjs.Gay2Code.GDposition_9595placeholderObjects3.push(gdjs.Gay2Code.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.Gay2Code.eventsList1(runtimeScene);} //Subevents end.
}
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("screen_fade"), gdjs.Gay2Code.GDscreen_9595fadeObjects1);
{for(var i = 0, len = gdjs.Gay2Code.GDscreen_9595fadeObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDscreen_9595fadeObjects1[i].getBehavior("Tween").addObjectOpacityTween("fade_in", 0, "linear", 1000, true);
}
}}

}


};gdjs.Gay2Code.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "Fade");
}
{ //Subevents
gdjs.Gay2Code.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.Gay2Code.mapOfGDgdjs_9546Gay2Code_9546GDcard_95959595blowfishObjects2ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595crabObjects2ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595seahorseObjects2ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595snailObjects2ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595seagrassObjects2ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595coralObjects2ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595anemoneObjects2ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595plasticbagObjects2Objects = Hashtable.newFrom({"card_blowfish": gdjs.Gay2Code.GDcard_9595blowfishObjects2, "card_crab": gdjs.Gay2Code.GDcard_9595crabObjects2, "card_seahorse": gdjs.Gay2Code.GDcard_9595seahorseObjects2, "card_snail": gdjs.Gay2Code.GDcard_9595snailObjects2, "card_seagrass": gdjs.Gay2Code.GDcard_9595seagrassObjects2, "card_coral": gdjs.Gay2Code.GDcard_9595coralObjects2, "card_anemone": gdjs.Gay2Code.GDcard_9595anemoneObjects2, "card_plasticbag": gdjs.Gay2Code.GDcard_9595plasticbagObjects2});
gdjs.Gay2Code.eventsList4 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "show_cards");
}{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "show_cards");
}{runtimeScene.getScene().getVariables().getFromIndex(4).setString("show_cards");
}}

}


};gdjs.Gay2Code.eventsList5 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.Gay2Code.GDcard_9595anemoneObjects2, gdjs.Gay2Code.GDcard_9595anemoneObjects3);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595blowfishObjects2, gdjs.Gay2Code.GDcard_9595blowfishObjects3);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595coralObjects2, gdjs.Gay2Code.GDcard_9595coralObjects3);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595crabObjects2, gdjs.Gay2Code.GDcard_9595crabObjects3);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595plasticbagObjects2, gdjs.Gay2Code.GDcard_9595plasticbagObjects3);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595seagrassObjects2, gdjs.Gay2Code.GDcard_9595seagrassObjects3);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595seahorseObjects2, gdjs.Gay2Code.GDcard_9595seahorseObjects3);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595snailObjects2, gdjs.Gay2Code.GDcard_9595snailObjects3);

{for(var i = 0, len = gdjs.Gay2Code.GDcard_9595blowfishObjects3.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595blowfishObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595crabObjects3.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595crabObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seahorseObjects3.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seahorseObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595snailObjects3.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595snailObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seagrassObjects3.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seagrassObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595coralObjects3.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595coralObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595anemoneObjects3.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595anemoneObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595plasticbagObjects3.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595plasticbagObjects3[i].getBehavior("Tween").removeTween("uncover_1");
}
}{for(var i = 0, len = gdjs.Gay2Code.GDcard_9595blowfishObjects3.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595blowfishObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595crabObjects3.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595crabObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seahorseObjects3.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seahorseObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595snailObjects3.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595snailObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seagrassObjects3.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seagrassObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595coralObjects3.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595coralObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595anemoneObjects3.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595anemoneObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595plasticbagObjects3.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595plasticbagObjects3[i].getBehavior("Tween").addObjectScaleXTween("uncover_0", 0, "linear", 125, false, false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) == 2;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Gay2Code.GDcard_9595anemoneObjects2, gdjs.Gay2Code.GDcard_9595anemoneObjects3);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595blowfishObjects2, gdjs.Gay2Code.GDcard_9595blowfishObjects3);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595coralObjects2, gdjs.Gay2Code.GDcard_9595coralObjects3);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595crabObjects2, gdjs.Gay2Code.GDcard_9595crabObjects3);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595plasticbagObjects2, gdjs.Gay2Code.GDcard_9595plasticbagObjects3);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595seagrassObjects2, gdjs.Gay2Code.GDcard_9595seagrassObjects3);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595seahorseObjects2, gdjs.Gay2Code.GDcard_9595seahorseObjects3);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595snailObjects2, gdjs.Gay2Code.GDcard_9595snailObjects3);

{runtimeScene.getScene().getVariables().getFromIndex(2).setString((gdjs.RuntimeObject.getVariableString(((gdjs.Gay2Code.GDcard_9595plasticbagObjects3.length === 0 ) ? ((gdjs.Gay2Code.GDcard_9595anemoneObjects3.length === 0 ) ? ((gdjs.Gay2Code.GDcard_9595coralObjects3.length === 0 ) ? ((gdjs.Gay2Code.GDcard_9595seagrassObjects3.length === 0 ) ? ((gdjs.Gay2Code.GDcard_9595snailObjects3.length === 0 ) ? ((gdjs.Gay2Code.GDcard_9595seahorseObjects3.length === 0 ) ? ((gdjs.Gay2Code.GDcard_9595crabObjects3.length === 0 ) ? ((gdjs.Gay2Code.GDcard_9595blowfishObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Gay2Code.GDcard_9595blowfishObjects3[0].getVariables()) : gdjs.Gay2Code.GDcard_9595crabObjects3[0].getVariables()) : gdjs.Gay2Code.GDcard_9595seahorseObjects3[0].getVariables()) : gdjs.Gay2Code.GDcard_9595snailObjects3[0].getVariables()) : gdjs.Gay2Code.GDcard_9595seagrassObjects3[0].getVariables()) : gdjs.Gay2Code.GDcard_9595coralObjects3[0].getVariables()) : gdjs.Gay2Code.GDcard_9595anemoneObjects3[0].getVariables()) : gdjs.Gay2Code.GDcard_9595plasticbagObjects3[0].getVariables()).get("id"))));
}
{ //Subevents
gdjs.Gay2Code.eventsList4(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) == 1;
if (isConditionTrue_0) {
/* Reuse gdjs.Gay2Code.GDcard_9595anemoneObjects2 */
/* Reuse gdjs.Gay2Code.GDcard_9595blowfishObjects2 */
/* Reuse gdjs.Gay2Code.GDcard_9595coralObjects2 */
/* Reuse gdjs.Gay2Code.GDcard_9595crabObjects2 */
/* Reuse gdjs.Gay2Code.GDcard_9595plasticbagObjects2 */
/* Reuse gdjs.Gay2Code.GDcard_9595seagrassObjects2 */
/* Reuse gdjs.Gay2Code.GDcard_9595seahorseObjects2 */
/* Reuse gdjs.Gay2Code.GDcard_9595snailObjects2 */
{runtimeScene.getScene().getVariables().getFromIndex(0).setString((gdjs.RuntimeObject.getVariableString(((gdjs.Gay2Code.GDcard_9595plasticbagObjects2.length === 0 ) ? ((gdjs.Gay2Code.GDcard_9595anemoneObjects2.length === 0 ) ? ((gdjs.Gay2Code.GDcard_9595coralObjects2.length === 0 ) ? ((gdjs.Gay2Code.GDcard_9595seagrassObjects2.length === 0 ) ? ((gdjs.Gay2Code.GDcard_9595snailObjects2.length === 0 ) ? ((gdjs.Gay2Code.GDcard_9595seahorseObjects2.length === 0 ) ? ((gdjs.Gay2Code.GDcard_9595crabObjects2.length === 0 ) ? ((gdjs.Gay2Code.GDcard_9595blowfishObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Gay2Code.GDcard_9595blowfishObjects2[0].getVariables()) : gdjs.Gay2Code.GDcard_9595crabObjects2[0].getVariables()) : gdjs.Gay2Code.GDcard_9595seahorseObjects2[0].getVariables()) : gdjs.Gay2Code.GDcard_9595snailObjects2[0].getVariables()) : gdjs.Gay2Code.GDcard_9595seagrassObjects2[0].getVariables()) : gdjs.Gay2Code.GDcard_9595coralObjects2[0].getVariables()) : gdjs.Gay2Code.GDcard_9595anemoneObjects2[0].getVariables()) : gdjs.Gay2Code.GDcard_9595plasticbagObjects2[0].getVariables()).get("id"))));
}}

}


};gdjs.Gay2Code.eventsList6 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("card_anemone"), gdjs.Gay2Code.GDcard_9595anemoneObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish"), gdjs.Gay2Code.GDcard_9595blowfishObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_coral"), gdjs.Gay2Code.GDcard_9595coralObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_crab"), gdjs.Gay2Code.GDcard_9595crabObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag"), gdjs.Gay2Code.GDcard_9595plasticbagObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass"), gdjs.Gay2Code.GDcard_9595seagrassObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse"), gdjs.Gay2Code.GDcard_9595seahorseObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_snail"), gdjs.Gay2Code.GDcard_9595snailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Gay2Code.mapOfGDgdjs_9546Gay2Code_9546GDcard_95959595blowfishObjects2ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595crabObjects2ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595seahorseObjects2ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595snailObjects2ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595seagrassObjects2ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595coralObjects2ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595anemoneObjects2ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595plasticbagObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595blowfishObjects2.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595blowfishObjects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595blowfishObjects2[k] = gdjs.Gay2Code.GDcard_9595blowfishObjects2[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595blowfishObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595crabObjects2.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595crabObjects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595crabObjects2[k] = gdjs.Gay2Code.GDcard_9595crabObjects2[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595crabObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595seahorseObjects2.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595seahorseObjects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595seahorseObjects2[k] = gdjs.Gay2Code.GDcard_9595seahorseObjects2[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595seahorseObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595snailObjects2.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595snailObjects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595snailObjects2[k] = gdjs.Gay2Code.GDcard_9595snailObjects2[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595snailObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595seagrassObjects2.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595seagrassObjects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595seagrassObjects2[k] = gdjs.Gay2Code.GDcard_9595seagrassObjects2[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595seagrassObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595coralObjects2.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595coralObjects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595coralObjects2[k] = gdjs.Gay2Code.GDcard_9595coralObjects2[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595coralObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595anemoneObjects2.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595anemoneObjects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595anemoneObjects2[k] = gdjs.Gay2Code.GDcard_9595anemoneObjects2[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595anemoneObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595plasticbagObjects2.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595plasticbagObjects2[i].isCurrentAnimationName("back") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595plasticbagObjects2[k] = gdjs.Gay2Code.GDcard_9595plasticbagObjects2[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595plasticbagObjects2.length = k;
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "sounds/cockatrice_playcard.mp3", false, 100, 1);
}
{ //Subevents
gdjs.Gay2Code.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.Gay2Code.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Gay2Code.GDcard_9595anemoneObjects2 */
/* Reuse gdjs.Gay2Code.GDcard_9595blowfishObjects2 */
/* Reuse gdjs.Gay2Code.GDcard_9595coralObjects2 */
/* Reuse gdjs.Gay2Code.GDcard_9595crabObjects2 */
/* Reuse gdjs.Gay2Code.GDcard_9595plasticbagObjects2 */
/* Reuse gdjs.Gay2Code.GDcard_9595seagrassObjects2 */
/* Reuse gdjs.Gay2Code.GDcard_9595seahorseObjects2 */
/* Reuse gdjs.Gay2Code.GDcard_9595snailObjects2 */
{for(var i = 0, len = gdjs.Gay2Code.GDcard_9595blowfishObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595blowfishObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595crabObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595crabObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seahorseObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seahorseObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595snailObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595snailObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seagrassObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seagrassObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595coralObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595coralObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595anemoneObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595anemoneObjects2[i].setAnimationName("front");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595plasticbagObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595plasticbagObjects2[i].setAnimationName("front");
}
}{for(var i = 0, len = gdjs.Gay2Code.GDcard_9595blowfishObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595blowfishObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595crabObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595crabObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seahorseObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seahorseObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595snailObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595snailObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seagrassObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seagrassObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595coralObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595coralObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595anemoneObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595anemoneObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595plasticbagObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595plasticbagObjects2[i].getBehavior("Tween").removeTween("uncover_0");
}
}{for(var i = 0, len = gdjs.Gay2Code.GDcard_9595blowfishObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595blowfishObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595crabObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595crabObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seahorseObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seahorseObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595snailObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595snailObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seagrassObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seagrassObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595coralObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595coralObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595anemoneObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595anemoneObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595plasticbagObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595plasticbagObjects2[i].getBehavior("Tween").addObjectScaleXTween("uncover_1", 1, "linear", 125, false, false);
}
}}

}


};gdjs.Gay2Code.mapOfGDgdjs_9546Gay2Code_9546GDcard_95959595blowfishObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595crabObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595seahorseObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595snailObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595seagrassObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595coralObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595anemoneObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595plasticbagObjects4Objects = Hashtable.newFrom({"card_blowfish": gdjs.Gay2Code.GDcard_9595blowfishObjects4, "card_crab": gdjs.Gay2Code.GDcard_9595crabObjects4, "card_seahorse": gdjs.Gay2Code.GDcard_9595seahorseObjects4, "card_snail": gdjs.Gay2Code.GDcard_9595snailObjects4, "card_seagrass": gdjs.Gay2Code.GDcard_9595seagrassObjects4, "card_coral": gdjs.Gay2Code.GDcard_9595coralObjects4, "card_anemone": gdjs.Gay2Code.GDcard_9595anemoneObjects4, "card_plasticbag": gdjs.Gay2Code.GDcard_9595plasticbagObjects4});
gdjs.Gay2Code.mapOfGDgdjs_9546Gay2Code_9546GDstar_95959595particleObjects6Objects = Hashtable.newFrom({"star_particle": gdjs.Gay2Code.GDstar_9595particleObjects6});
gdjs.Gay2Code.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.Gay2Code.GDcard_9595anemoneObjects5, gdjs.Gay2Code.GDcard_9595anemoneObjects6);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595blowfishObjects5, gdjs.Gay2Code.GDcard_9595blowfishObjects6);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595coralObjects5, gdjs.Gay2Code.GDcard_9595coralObjects6);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595crabObjects5, gdjs.Gay2Code.GDcard_9595crabObjects6);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595plasticbagObjects5, gdjs.Gay2Code.GDcard_9595plasticbagObjects6);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595seagrassObjects5, gdjs.Gay2Code.GDcard_9595seagrassObjects6);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595seahorseObjects5, gdjs.Gay2Code.GDcard_9595seahorseObjects6);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595snailObjects5, gdjs.Gay2Code.GDcard_9595snailObjects6);

gdjs.Gay2Code.GDstar_9595particleObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gay2Code.mapOfGDgdjs_9546Gay2Code_9546GDstar_95959595particleObjects6Objects, (( gdjs.Gay2Code.GDcard_9595plasticbagObjects6.length === 0 ) ? (( gdjs.Gay2Code.GDcard_9595anemoneObjects6.length === 0 ) ? (( gdjs.Gay2Code.GDcard_9595coralObjects6.length === 0 ) ? (( gdjs.Gay2Code.GDcard_9595seagrassObjects6.length === 0 ) ? (( gdjs.Gay2Code.GDcard_9595snailObjects6.length === 0 ) ? (( gdjs.Gay2Code.GDcard_9595seahorseObjects6.length === 0 ) ? (( gdjs.Gay2Code.GDcard_9595crabObjects6.length === 0 ) ? (( gdjs.Gay2Code.GDcard_9595blowfishObjects6.length === 0 ) ? 0 :gdjs.Gay2Code.GDcard_9595blowfishObjects6[0].getPointX("")) :gdjs.Gay2Code.GDcard_9595crabObjects6[0].getPointX("")) :gdjs.Gay2Code.GDcard_9595seahorseObjects6[0].getPointX("")) :gdjs.Gay2Code.GDcard_9595snailObjects6[0].getPointX("")) :gdjs.Gay2Code.GDcard_9595seagrassObjects6[0].getPointX("")) :gdjs.Gay2Code.GDcard_9595coralObjects6[0].getPointX("")) :gdjs.Gay2Code.GDcard_9595anemoneObjects6[0].getPointX("")) :gdjs.Gay2Code.GDcard_9595plasticbagObjects6[0].getPointX("")), (( gdjs.Gay2Code.GDcard_9595plasticbagObjects6.length === 0 ) ? (( gdjs.Gay2Code.GDcard_9595anemoneObjects6.length === 0 ) ? (( gdjs.Gay2Code.GDcard_9595coralObjects6.length === 0 ) ? (( gdjs.Gay2Code.GDcard_9595seagrassObjects6.length === 0 ) ? (( gdjs.Gay2Code.GDcard_9595snailObjects6.length === 0 ) ? (( gdjs.Gay2Code.GDcard_9595seahorseObjects6.length === 0 ) ? (( gdjs.Gay2Code.GDcard_9595crabObjects6.length === 0 ) ? (( gdjs.Gay2Code.GDcard_9595blowfishObjects6.length === 0 ) ? 0 :gdjs.Gay2Code.GDcard_9595blowfishObjects6[0].getPointY("")) :gdjs.Gay2Code.GDcard_9595crabObjects6[0].getPointY("")) :gdjs.Gay2Code.GDcard_9595seahorseObjects6[0].getPointY("")) :gdjs.Gay2Code.GDcard_9595snailObjects6[0].getPointY("")) :gdjs.Gay2Code.GDcard_9595seagrassObjects6[0].getPointY("")) :gdjs.Gay2Code.GDcard_9595coralObjects6[0].getPointY("")) :gdjs.Gay2Code.GDcard_9595anemoneObjects6[0].getPointY("")) :gdjs.Gay2Code.GDcard_9595plasticbagObjects6[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Gay2Code.GDstar_9595particleObjects6.length ;i < len;++i) {
    gdjs.Gay2Code.GDstar_9595particleObjects6[i].setZOrder(100);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "sounds/cuckoo.wav", false, 100, 1);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15665428);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Gay2Code.GDcard_9595anemoneObjects5, gdjs.Gay2Code.GDcard_9595anemoneObjects6);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595blowfishObjects5, gdjs.Gay2Code.GDcard_9595blowfishObjects6);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595coralObjects5, gdjs.Gay2Code.GDcard_9595coralObjects6);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595crabObjects5, gdjs.Gay2Code.GDcard_9595crabObjects6);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595plasticbagObjects5, gdjs.Gay2Code.GDcard_9595plasticbagObjects6);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595seagrassObjects5, gdjs.Gay2Code.GDcard_9595seagrassObjects6);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595seahorseObjects5, gdjs.Gay2Code.GDcard_9595seahorseObjects6);

gdjs.copyArray(gdjs.Gay2Code.GDcard_9595snailObjects5, gdjs.Gay2Code.GDcard_9595snailObjects6);

{for(var i = 0, len = gdjs.Gay2Code.GDcard_9595blowfishObjects6.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595blowfishObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595crabObjects6.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595crabObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seahorseObjects6.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seahorseObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595snailObjects6.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595snailObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seagrassObjects6.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seagrassObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595coralObjects6.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595coralObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595anemoneObjects6.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595anemoneObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595plasticbagObjects6.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595plasticbagObjects6[i].getBehavior("Tween").addObjectScaleTween("vanish", 0, 0, "elastic", 1000, true, false);
}
}}

}


};gdjs.Gay2Code.eventsList9 = function(runtimeScene) {

{

/* Reuse gdjs.Gay2Code.GDcard_9595anemoneObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595blowfishObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595coralObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595crabObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595plasticbagObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595seagrassObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595seahorseObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595snailObjects4 */

gdjs.Gay2Code.forEachTotalCount5 = 0;
gdjs.Gay2Code.forEachObjects5.length = 0;
gdjs.Gay2Code.forEachCount0_5 = gdjs.Gay2Code.GDcard_9595blowfishObjects4.length;
gdjs.Gay2Code.forEachTotalCount5 += gdjs.Gay2Code.forEachCount0_5;
gdjs.Gay2Code.forEachObjects5.push.apply(gdjs.Gay2Code.forEachObjects5,gdjs.Gay2Code.GDcard_9595blowfishObjects4);
gdjs.Gay2Code.forEachCount1_5 = gdjs.Gay2Code.GDcard_9595crabObjects4.length;
gdjs.Gay2Code.forEachTotalCount5 += gdjs.Gay2Code.forEachCount1_5;
gdjs.Gay2Code.forEachObjects5.push.apply(gdjs.Gay2Code.forEachObjects5,gdjs.Gay2Code.GDcard_9595crabObjects4);
gdjs.Gay2Code.forEachCount2_5 = gdjs.Gay2Code.GDcard_9595seahorseObjects4.length;
gdjs.Gay2Code.forEachTotalCount5 += gdjs.Gay2Code.forEachCount2_5;
gdjs.Gay2Code.forEachObjects5.push.apply(gdjs.Gay2Code.forEachObjects5,gdjs.Gay2Code.GDcard_9595seahorseObjects4);
gdjs.Gay2Code.forEachCount3_5 = gdjs.Gay2Code.GDcard_9595snailObjects4.length;
gdjs.Gay2Code.forEachTotalCount5 += gdjs.Gay2Code.forEachCount3_5;
gdjs.Gay2Code.forEachObjects5.push.apply(gdjs.Gay2Code.forEachObjects5,gdjs.Gay2Code.GDcard_9595snailObjects4);
gdjs.Gay2Code.forEachCount4_5 = gdjs.Gay2Code.GDcard_9595seagrassObjects4.length;
gdjs.Gay2Code.forEachTotalCount5 += gdjs.Gay2Code.forEachCount4_5;
gdjs.Gay2Code.forEachObjects5.push.apply(gdjs.Gay2Code.forEachObjects5,gdjs.Gay2Code.GDcard_9595seagrassObjects4);
gdjs.Gay2Code.forEachCount5_5 = gdjs.Gay2Code.GDcard_9595coralObjects4.length;
gdjs.Gay2Code.forEachTotalCount5 += gdjs.Gay2Code.forEachCount5_5;
gdjs.Gay2Code.forEachObjects5.push.apply(gdjs.Gay2Code.forEachObjects5,gdjs.Gay2Code.GDcard_9595coralObjects4);
gdjs.Gay2Code.forEachCount6_5 = gdjs.Gay2Code.GDcard_9595anemoneObjects4.length;
gdjs.Gay2Code.forEachTotalCount5 += gdjs.Gay2Code.forEachCount6_5;
gdjs.Gay2Code.forEachObjects5.push.apply(gdjs.Gay2Code.forEachObjects5,gdjs.Gay2Code.GDcard_9595anemoneObjects4);
gdjs.Gay2Code.forEachCount7_5 = gdjs.Gay2Code.GDcard_9595plasticbagObjects4.length;
gdjs.Gay2Code.forEachTotalCount5 += gdjs.Gay2Code.forEachCount7_5;
gdjs.Gay2Code.forEachObjects5.push.apply(gdjs.Gay2Code.forEachObjects5,gdjs.Gay2Code.GDcard_9595plasticbagObjects4);
for (gdjs.Gay2Code.forEachIndex5 = 0;gdjs.Gay2Code.forEachIndex5 < gdjs.Gay2Code.forEachTotalCount5;++gdjs.Gay2Code.forEachIndex5) {
gdjs.Gay2Code.GDcard_9595anemoneObjects5.length = 0;

gdjs.Gay2Code.GDcard_9595blowfishObjects5.length = 0;

gdjs.Gay2Code.GDcard_9595coralObjects5.length = 0;

gdjs.Gay2Code.GDcard_9595crabObjects5.length = 0;

gdjs.Gay2Code.GDcard_9595plasticbagObjects5.length = 0;

gdjs.Gay2Code.GDcard_9595seagrassObjects5.length = 0;

gdjs.Gay2Code.GDcard_9595seahorseObjects5.length = 0;

gdjs.Gay2Code.GDcard_9595snailObjects5.length = 0;


if (gdjs.Gay2Code.forEachIndex5 < gdjs.Gay2Code.forEachCount0_5) {
    gdjs.Gay2Code.GDcard_9595blowfishObjects5.push(gdjs.Gay2Code.forEachObjects5[gdjs.Gay2Code.forEachIndex5]);
}
else if (gdjs.Gay2Code.forEachIndex5 < gdjs.Gay2Code.forEachCount0_5+gdjs.Gay2Code.forEachCount1_5) {
    gdjs.Gay2Code.GDcard_9595crabObjects5.push(gdjs.Gay2Code.forEachObjects5[gdjs.Gay2Code.forEachIndex5]);
}
else if (gdjs.Gay2Code.forEachIndex5 < gdjs.Gay2Code.forEachCount0_5+gdjs.Gay2Code.forEachCount1_5+gdjs.Gay2Code.forEachCount2_5) {
    gdjs.Gay2Code.GDcard_9595seahorseObjects5.push(gdjs.Gay2Code.forEachObjects5[gdjs.Gay2Code.forEachIndex5]);
}
else if (gdjs.Gay2Code.forEachIndex5 < gdjs.Gay2Code.forEachCount0_5+gdjs.Gay2Code.forEachCount1_5+gdjs.Gay2Code.forEachCount2_5+gdjs.Gay2Code.forEachCount3_5) {
    gdjs.Gay2Code.GDcard_9595snailObjects5.push(gdjs.Gay2Code.forEachObjects5[gdjs.Gay2Code.forEachIndex5]);
}
else if (gdjs.Gay2Code.forEachIndex5 < gdjs.Gay2Code.forEachCount0_5+gdjs.Gay2Code.forEachCount1_5+gdjs.Gay2Code.forEachCount2_5+gdjs.Gay2Code.forEachCount3_5+gdjs.Gay2Code.forEachCount4_5) {
    gdjs.Gay2Code.GDcard_9595seagrassObjects5.push(gdjs.Gay2Code.forEachObjects5[gdjs.Gay2Code.forEachIndex5]);
}
else if (gdjs.Gay2Code.forEachIndex5 < gdjs.Gay2Code.forEachCount0_5+gdjs.Gay2Code.forEachCount1_5+gdjs.Gay2Code.forEachCount2_5+gdjs.Gay2Code.forEachCount3_5+gdjs.Gay2Code.forEachCount4_5+gdjs.Gay2Code.forEachCount5_5) {
    gdjs.Gay2Code.GDcard_9595coralObjects5.push(gdjs.Gay2Code.forEachObjects5[gdjs.Gay2Code.forEachIndex5]);
}
else if (gdjs.Gay2Code.forEachIndex5 < gdjs.Gay2Code.forEachCount0_5+gdjs.Gay2Code.forEachCount1_5+gdjs.Gay2Code.forEachCount2_5+gdjs.Gay2Code.forEachCount3_5+gdjs.Gay2Code.forEachCount4_5+gdjs.Gay2Code.forEachCount5_5+gdjs.Gay2Code.forEachCount6_5) {
    gdjs.Gay2Code.GDcard_9595anemoneObjects5.push(gdjs.Gay2Code.forEachObjects5[gdjs.Gay2Code.forEachIndex5]);
}
else if (gdjs.Gay2Code.forEachIndex5 < gdjs.Gay2Code.forEachCount0_5+gdjs.Gay2Code.forEachCount1_5+gdjs.Gay2Code.forEachCount2_5+gdjs.Gay2Code.forEachCount3_5+gdjs.Gay2Code.forEachCount4_5+gdjs.Gay2Code.forEachCount5_5+gdjs.Gay2Code.forEachCount6_5+gdjs.Gay2Code.forEachCount7_5) {
    gdjs.Gay2Code.GDcard_9595plasticbagObjects5.push(gdjs.Gay2Code.forEachObjects5[gdjs.Gay2Code.forEachIndex5]);
}
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.Gay2Code.eventsList8(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Gay2Code.eventsList10 = function(runtimeScene) {

{

/* Reuse gdjs.Gay2Code.GDcard_9595anemoneObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595blowfishObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595coralObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595crabObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595plasticbagObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595seagrassObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595seahorseObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595snailObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595blowfishObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595blowfishObjects4[i].getVariableString(gdjs.Gay2Code.GDcard_9595blowfishObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595blowfishObjects4[k] = gdjs.Gay2Code.GDcard_9595blowfishObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595blowfishObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595crabObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595crabObjects4[i].getVariableString(gdjs.Gay2Code.GDcard_9595crabObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595crabObjects4[k] = gdjs.Gay2Code.GDcard_9595crabObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595crabObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595seahorseObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595seahorseObjects4[i].getVariableString(gdjs.Gay2Code.GDcard_9595seahorseObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595seahorseObjects4[k] = gdjs.Gay2Code.GDcard_9595seahorseObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595seahorseObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595snailObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595snailObjects4[i].getVariableString(gdjs.Gay2Code.GDcard_9595snailObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595snailObjects4[k] = gdjs.Gay2Code.GDcard_9595snailObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595snailObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595seagrassObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595seagrassObjects4[i].getVariableString(gdjs.Gay2Code.GDcard_9595seagrassObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595seagrassObjects4[k] = gdjs.Gay2Code.GDcard_9595seagrassObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595seagrassObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595coralObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595coralObjects4[i].getVariableString(gdjs.Gay2Code.GDcard_9595coralObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595coralObjects4[k] = gdjs.Gay2Code.GDcard_9595coralObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595coralObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595anemoneObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595anemoneObjects4[i].getVariableString(gdjs.Gay2Code.GDcard_9595anemoneObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595anemoneObjects4[k] = gdjs.Gay2Code.GDcard_9595anemoneObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595anemoneObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595plasticbagObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595plasticbagObjects4[i].getVariableString(gdjs.Gay2Code.GDcard_9595plasticbagObjects4[i].getVariables().get("id")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595plasticbagObjects4[k] = gdjs.Gay2Code.GDcard_9595plasticbagObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595plasticbagObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gay2Code.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.Gay2Code.eventsList11 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("card_anemone"), gdjs.Gay2Code.GDcard_9595anemoneObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish"), gdjs.Gay2Code.GDcard_9595blowfishObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_coral"), gdjs.Gay2Code.GDcard_9595coralObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_crab"), gdjs.Gay2Code.GDcard_9595crabObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag"), gdjs.Gay2Code.GDcard_9595plasticbagObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass"), gdjs.Gay2Code.GDcard_9595seagrassObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse"), gdjs.Gay2Code.GDcard_9595seahorseObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_snail"), gdjs.Gay2Code.GDcard_9595snailObjects4);
{gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gay2Code.mapOfGDgdjs_9546Gay2Code_9546GDcard_95959595blowfishObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595crabObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595seahorseObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595snailObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595seagrassObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595coralObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595anemoneObjects4ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595plasticbagObjects4Objects);
}
{ //Subevents
gdjs.Gay2Code.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.Gay2Code.eventsList12 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("pairs"), gdjs.Gay2Code.GDpairsObjects4);
{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.Gay2Code.GDpairsObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDpairsObjects4[i].setColor("255;255;255");
}
}{for(var i = 0, len = gdjs.Gay2Code.GDpairsObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDpairsObjects4[i].getBehavior("Tween").addObjectColorTween("flash", "179;211;48", "easeInOutQuad", 250, false, false);
}
}
{ //Subevents
gdjs.Gay2Code.eventsList11(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("card_anemone"), gdjs.Gay2Code.GDcard_9595anemoneObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish"), gdjs.Gay2Code.GDcard_9595blowfishObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_coral"), gdjs.Gay2Code.GDcard_9595coralObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_crab"), gdjs.Gay2Code.GDcard_9595crabObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag"), gdjs.Gay2Code.GDcard_9595plasticbagObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass"), gdjs.Gay2Code.GDcard_9595seagrassObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse"), gdjs.Gay2Code.GDcard_9595seahorseObjects4);
gdjs.copyArray(runtimeScene.getObjects("card_snail"), gdjs.Gay2Code.GDcard_9595snailObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595blowfishObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595blowfishObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595blowfishObjects4[k] = gdjs.Gay2Code.GDcard_9595blowfishObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595blowfishObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595crabObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595crabObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595crabObjects4[k] = gdjs.Gay2Code.GDcard_9595crabObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595crabObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595seahorseObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595seahorseObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595seahorseObjects4[k] = gdjs.Gay2Code.GDcard_9595seahorseObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595seahorseObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595snailObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595snailObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595snailObjects4[k] = gdjs.Gay2Code.GDcard_9595snailObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595snailObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595seagrassObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595seagrassObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595seagrassObjects4[k] = gdjs.Gay2Code.GDcard_9595seagrassObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595seagrassObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595coralObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595coralObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595coralObjects4[k] = gdjs.Gay2Code.GDcard_9595coralObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595coralObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595anemoneObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595anemoneObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595anemoneObjects4[k] = gdjs.Gay2Code.GDcard_9595anemoneObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595anemoneObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595plasticbagObjects4.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595plasticbagObjects4[i].isCurrentAnimationName("front") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595plasticbagObjects4[k] = gdjs.Gay2Code.GDcard_9595plasticbagObjects4[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595plasticbagObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15666692);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Gay2Code.GDcard_9595anemoneObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595blowfishObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595coralObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595crabObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595plasticbagObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595seagrassObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595seahorseObjects4 */
/* Reuse gdjs.Gay2Code.GDcard_9595snailObjects4 */
{for(var i = 0, len = gdjs.Gay2Code.GDcard_9595blowfishObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595blowfishObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595crabObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595crabObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seahorseObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seahorseObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595snailObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595snailObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seagrassObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seagrassObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595coralObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595coralObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595anemoneObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595anemoneObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595plasticbagObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595plasticbagObjects4[i].getBehavior("Tween").removeTween("cover_1");
}
}{for(var i = 0, len = gdjs.Gay2Code.GDcard_9595blowfishObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595blowfishObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595crabObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595crabObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seahorseObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seahorseObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595snailObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595snailObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seagrassObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seagrassObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595coralObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595coralObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595anemoneObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595anemoneObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595plasticbagObjects4.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595plasticbagObjects4[i].getBehavior("Tween").addObjectScaleXTween("cover_0", 0, "linear", 125, false, false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(0);
}}

}


};gdjs.Gay2Code.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Gay2Code.eventsList12(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(4).setString("player_turn");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "show_cards");
}}

}


};gdjs.Gay2Code.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Gay2Code.GDcard_9595anemoneObjects1 */
/* Reuse gdjs.Gay2Code.GDcard_9595blowfishObjects1 */
/* Reuse gdjs.Gay2Code.GDcard_9595coralObjects1 */
/* Reuse gdjs.Gay2Code.GDcard_9595crabObjects1 */
/* Reuse gdjs.Gay2Code.GDcard_9595plasticbagObjects1 */
/* Reuse gdjs.Gay2Code.GDcard_9595seagrassObjects1 */
/* Reuse gdjs.Gay2Code.GDcard_9595seahorseObjects1 */
/* Reuse gdjs.Gay2Code.GDcard_9595snailObjects1 */
{for(var i = 0, len = gdjs.Gay2Code.GDcard_9595blowfishObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595blowfishObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595crabObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595crabObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seahorseObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seahorseObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595snailObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595snailObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seagrassObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seagrassObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595coralObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595coralObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595anemoneObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595anemoneObjects1[i].setAnimationName("back");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595plasticbagObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595plasticbagObjects1[i].setAnimationName("back");
}
}{for(var i = 0, len = gdjs.Gay2Code.GDcard_9595blowfishObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595blowfishObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595crabObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595crabObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seahorseObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seahorseObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595snailObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595snailObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seagrassObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seagrassObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595coralObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595coralObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595anemoneObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595anemoneObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595plasticbagObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595plasticbagObjects1[i].getBehavior("Tween").removeTween("cover_0");
}
}{for(var i = 0, len = gdjs.Gay2Code.GDcard_9595blowfishObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595blowfishObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595crabObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595crabObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seahorseObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seahorseObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595snailObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595snailObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595seagrassObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595seagrassObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595coralObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595coralObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595anemoneObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595anemoneObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
for(var i = 0, len = gdjs.Gay2Code.GDcard_9595plasticbagObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDcard_9595plasticbagObjects1[i].getBehavior("Tween").addObjectScaleXTween("cover_1", 1, "linear", 125, false, false);
}
}}

}


};gdjs.Gay2Code.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(4)) == "player_turn";
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gay2Code.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("card_anemone"), gdjs.Gay2Code.GDcard_9595anemoneObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish"), gdjs.Gay2Code.GDcard_9595blowfishObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_coral"), gdjs.Gay2Code.GDcard_9595coralObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_crab"), gdjs.Gay2Code.GDcard_9595crabObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag"), gdjs.Gay2Code.GDcard_9595plasticbagObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass"), gdjs.Gay2Code.GDcard_9595seagrassObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse"), gdjs.Gay2Code.GDcard_9595seahorseObjects2);
gdjs.copyArray(runtimeScene.getObjects("card_snail"), gdjs.Gay2Code.GDcard_9595snailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595blowfishObjects2.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595blowfishObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595blowfishObjects2[k] = gdjs.Gay2Code.GDcard_9595blowfishObjects2[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595blowfishObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595crabObjects2.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595crabObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595crabObjects2[k] = gdjs.Gay2Code.GDcard_9595crabObjects2[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595crabObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595seahorseObjects2.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595seahorseObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595seahorseObjects2[k] = gdjs.Gay2Code.GDcard_9595seahorseObjects2[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595seahorseObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595snailObjects2.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595snailObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595snailObjects2[k] = gdjs.Gay2Code.GDcard_9595snailObjects2[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595snailObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595seagrassObjects2.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595seagrassObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595seagrassObjects2[k] = gdjs.Gay2Code.GDcard_9595seagrassObjects2[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595seagrassObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595coralObjects2.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595coralObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595coralObjects2[k] = gdjs.Gay2Code.GDcard_9595coralObjects2[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595coralObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595anemoneObjects2.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595anemoneObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595anemoneObjects2[k] = gdjs.Gay2Code.GDcard_9595anemoneObjects2[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595anemoneObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595plasticbagObjects2.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595plasticbagObjects2[i].getBehavior("Tween").hasFinished("uncover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595plasticbagObjects2[k] = gdjs.Gay2Code.GDcard_9595plasticbagObjects2[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595plasticbagObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gay2Code.eventsList7(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "show_cards") > 1.5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15659460);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gay2Code.eventsList13(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("card_anemone"), gdjs.Gay2Code.GDcard_9595anemoneObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish"), gdjs.Gay2Code.GDcard_9595blowfishObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_coral"), gdjs.Gay2Code.GDcard_9595coralObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_crab"), gdjs.Gay2Code.GDcard_9595crabObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag"), gdjs.Gay2Code.GDcard_9595plasticbagObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass"), gdjs.Gay2Code.GDcard_9595seagrassObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse"), gdjs.Gay2Code.GDcard_9595seahorseObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_snail"), gdjs.Gay2Code.GDcard_9595snailObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595blowfishObjects1.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595blowfishObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595blowfishObjects1[k] = gdjs.Gay2Code.GDcard_9595blowfishObjects1[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595blowfishObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595crabObjects1.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595crabObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595crabObjects1[k] = gdjs.Gay2Code.GDcard_9595crabObjects1[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595crabObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595seahorseObjects1.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595seahorseObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595seahorseObjects1[k] = gdjs.Gay2Code.GDcard_9595seahorseObjects1[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595seahorseObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595snailObjects1.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595snailObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595snailObjects1[k] = gdjs.Gay2Code.GDcard_9595snailObjects1[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595snailObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595seagrassObjects1.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595seagrassObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595seagrassObjects1[k] = gdjs.Gay2Code.GDcard_9595seagrassObjects1[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595seagrassObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595coralObjects1.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595coralObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595coralObjects1[k] = gdjs.Gay2Code.GDcard_9595coralObjects1[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595coralObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595anemoneObjects1.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595anemoneObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595anemoneObjects1[k] = gdjs.Gay2Code.GDcard_9595anemoneObjects1[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595anemoneObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Gay2Code.GDcard_9595plasticbagObjects1.length;i<l;++i) {
    if ( gdjs.Gay2Code.GDcard_9595plasticbagObjects1[i].getBehavior("Tween").hasFinished("cover_0") ) {
        isConditionTrue_0 = true;
        gdjs.Gay2Code.GDcard_9595plasticbagObjects1[k] = gdjs.Gay2Code.GDcard_9595plasticbagObjects1[i];
        ++k;
    }
}
gdjs.Gay2Code.GDcard_9595plasticbagObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15669268);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gay2Code.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.Gay2Code.mapOfGDgdjs_9546Gay2Code_9546GDnewgame_95959595buttonObjects2Objects = Hashtable.newFrom({"newgame_button": gdjs.Gay2Code.GDnewgame_9595buttonObjects2});
gdjs.Gay2Code.eventsList16 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15674860);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Gay2Code.GDnewgame_9595buttonObjects2, gdjs.Gay2Code.GDnewgame_9595buttonObjects3);

{for(var i = 0, len = gdjs.Gay2Code.GDnewgame_9595buttonObjects3.length ;i < len;++i) {
    gdjs.Gay2Code.GDnewgame_9595buttonObjects3[i].getBehavior("Tween").addObjectColorTween("shine", "255;255;255", "easeFromTo", 500, false, false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "sounds/pop.ogg", false, 100, 1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Gay3", false);
}}

}


};gdjs.Gay2Code.mapOfGDgdjs_9546Gay2Code_9546GDnewgame_95959595buttonObjects1Objects = Hashtable.newFrom({"newgame_button": gdjs.Gay2Code.GDnewgame_9595buttonObjects1});
gdjs.Gay2Code.eventsList17 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15677212);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Gay2Code.GDnewgame_9595buttonObjects1 */
{for(var i = 0, len = gdjs.Gay2Code.GDnewgame_9595buttonObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDnewgame_9595buttonObjects1[i].getBehavior("Tween").addObjectColorTween("shine", "200;200;200", "easeFromTo", 500, false, false);
}
}}

}


};gdjs.Gay2Code.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15672276);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("newgame"), gdjs.Gay2Code.GDnewgameObjects2);
gdjs.copyArray(runtimeScene.getObjects("newgame_button"), gdjs.Gay2Code.GDnewgame_9595buttonObjects2);
{for(var i = 0, len = gdjs.Gay2Code.GDnewgame_9595buttonObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDnewgame_9595buttonObjects2[i].setScale(0.5);
}
}{for(var i = 0, len = gdjs.Gay2Code.GDnewgame_9595buttonObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDnewgame_9595buttonObjects2[i].getBehavior("Tween").addObjectScaleTween("pop_up_button", 1, 1, "elastic", 1500, false, false);
}
}{for(var i = 0, len = gdjs.Gay2Code.GDnewgameObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDnewgameObjects2[i].setScaleX(0.5);
}
}{for(var i = 0, len = gdjs.Gay2Code.GDnewgameObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDnewgameObjects2[i].setScaleY(0.5);
}
}{for(var i = 0, len = gdjs.Gay2Code.GDnewgameObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDnewgameObjects2[i].getBehavior("Tween").addObjectScaleTween("pop_up_button_text", 1, 1, "elastic", 1500, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("newgame_button"), gdjs.Gay2Code.GDnewgame_9595buttonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Gay2Code.mapOfGDgdjs_9546Gay2Code_9546GDnewgame_95959595buttonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gay2Code.eventsList16(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("newgame_button"), gdjs.Gay2Code.GDnewgame_9595buttonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Gay2Code.mapOfGDgdjs_9546Gay2Code_9546GDnewgame_95959595buttonObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gay2Code.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.Gay2Code.eventsList19 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("pairs"), gdjs.Gay2Code.GDpairsObjects2);
{for(var i = 0, len = gdjs.Gay2Code.GDpairsObjects2.length ;i < len;++i) {
    gdjs.Gay2Code.GDpairsObjects2[i].setString("Pairs: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(3)));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "UI");
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gay2Code.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.Gay2Code.mapOfGDgdjs_9546Gay2Code_9546GDcard_95959595blowfishObjects1ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595crabObjects1ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595seahorseObjects1ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595snailObjects1ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595seagrassObjects1ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595coralObjects1ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595anemoneObjects1ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595plasticbagObjects1Objects = Hashtable.newFrom({"card_blowfish": gdjs.Gay2Code.GDcard_9595blowfishObjects1, "card_crab": gdjs.Gay2Code.GDcard_9595crabObjects1, "card_seahorse": gdjs.Gay2Code.GDcard_9595seahorseObjects1, "card_snail": gdjs.Gay2Code.GDcard_9595snailObjects1, "card_seagrass": gdjs.Gay2Code.GDcard_9595seagrassObjects1, "card_coral": gdjs.Gay2Code.GDcard_9595coralObjects1, "card_anemone": gdjs.Gay2Code.GDcard_9595anemoneObjects1, "card_plasticbag": gdjs.Gay2Code.GDcard_9595plasticbagObjects1});
gdjs.Gay2Code.eventsList20 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Gay2Code.GDui_9595backgroundObjects1 */
{for(var i = 0, len = gdjs.Gay2Code.GDui_9595backgroundObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDui_9595backgroundObjects1[i].getBehavior("Tween").addObjectOpacityTween("fade_out", 175, "linear", 1000, false);
}
}}

}


};gdjs.Gay2Code.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("card_anemone"), gdjs.Gay2Code.GDcard_9595anemoneObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_blowfish"), gdjs.Gay2Code.GDcard_9595blowfishObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_coral"), gdjs.Gay2Code.GDcard_9595coralObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_crab"), gdjs.Gay2Code.GDcard_9595crabObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_plasticbag"), gdjs.Gay2Code.GDcard_9595plasticbagObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_seagrass"), gdjs.Gay2Code.GDcard_9595seagrassObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_seahorse"), gdjs.Gay2Code.GDcard_9595seahorseObjects1);
gdjs.copyArray(runtimeScene.getObjects("card_snail"), gdjs.Gay2Code.GDcard_9595snailObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickedObjectsCount(gdjs.Gay2Code.mapOfGDgdjs_9546Gay2Code_9546GDcard_95959595blowfishObjects1ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595crabObjects1ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595seahorseObjects1ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595snailObjects1ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595seagrassObjects1ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595coralObjects1ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595anemoneObjects1ObjectsGDgdjs_9546Gay2Code_9546GDcard_95959595plasticbagObjects1Objects) <= 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15678220);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ui_background"), gdjs.Gay2Code.GDui_9595backgroundObjects1);
{gdjs.evtTools.sound.playSound(runtimeScene, "sounds/Rise.ogg", false, 100, 1);
}{for(var i = 0, len = gdjs.Gay2Code.GDui_9595backgroundObjects1.length ;i < len;++i) {
    gdjs.Gay2Code.GDui_9595backgroundObjects1[i].setOpacity(0);
}
}{gdjs.evtTools.camera.showLayer(runtimeScene, "UI");
}
{ //Subevents
gdjs.Gay2Code.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.Gay2Code.eventsList22 = function(runtimeScene) {

{


gdjs.Gay2Code.eventsList3(runtimeScene);
}


{


gdjs.Gay2Code.eventsList15(runtimeScene);
}


{


gdjs.Gay2Code.eventsList19(runtimeScene);
}


{


gdjs.Gay2Code.eventsList21(runtimeScene);
}


};

gdjs.Gay2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Gay2Code.GDcard_9595crabObjects1.length = 0;
gdjs.Gay2Code.GDcard_9595crabObjects2.length = 0;
gdjs.Gay2Code.GDcard_9595crabObjects3.length = 0;
gdjs.Gay2Code.GDcard_9595crabObjects4.length = 0;
gdjs.Gay2Code.GDcard_9595crabObjects5.length = 0;
gdjs.Gay2Code.GDcard_9595crabObjects6.length = 0;
gdjs.Gay2Code.GDcard_9595crabObjects7.length = 0;
gdjs.Gay2Code.GDcard_9595seahorseObjects1.length = 0;
gdjs.Gay2Code.GDcard_9595seahorseObjects2.length = 0;
gdjs.Gay2Code.GDcard_9595seahorseObjects3.length = 0;
gdjs.Gay2Code.GDcard_9595seahorseObjects4.length = 0;
gdjs.Gay2Code.GDcard_9595seahorseObjects5.length = 0;
gdjs.Gay2Code.GDcard_9595seahorseObjects6.length = 0;
gdjs.Gay2Code.GDcard_9595seahorseObjects7.length = 0;
gdjs.Gay2Code.GDcard_9595snailObjects1.length = 0;
gdjs.Gay2Code.GDcard_9595snailObjects2.length = 0;
gdjs.Gay2Code.GDcard_9595snailObjects3.length = 0;
gdjs.Gay2Code.GDcard_9595snailObjects4.length = 0;
gdjs.Gay2Code.GDcard_9595snailObjects5.length = 0;
gdjs.Gay2Code.GDcard_9595snailObjects6.length = 0;
gdjs.Gay2Code.GDcard_9595snailObjects7.length = 0;
gdjs.Gay2Code.GDcard_9595seagrassObjects1.length = 0;
gdjs.Gay2Code.GDcard_9595seagrassObjects2.length = 0;
gdjs.Gay2Code.GDcard_9595seagrassObjects3.length = 0;
gdjs.Gay2Code.GDcard_9595seagrassObjects4.length = 0;
gdjs.Gay2Code.GDcard_9595seagrassObjects5.length = 0;
gdjs.Gay2Code.GDcard_9595seagrassObjects6.length = 0;
gdjs.Gay2Code.GDcard_9595seagrassObjects7.length = 0;
gdjs.Gay2Code.GDcard_9595coralObjects1.length = 0;
gdjs.Gay2Code.GDcard_9595coralObjects2.length = 0;
gdjs.Gay2Code.GDcard_9595coralObjects3.length = 0;
gdjs.Gay2Code.GDcard_9595coralObjects4.length = 0;
gdjs.Gay2Code.GDcard_9595coralObjects5.length = 0;
gdjs.Gay2Code.GDcard_9595coralObjects6.length = 0;
gdjs.Gay2Code.GDcard_9595coralObjects7.length = 0;
gdjs.Gay2Code.GDcard_9595anemoneObjects1.length = 0;
gdjs.Gay2Code.GDcard_9595anemoneObjects2.length = 0;
gdjs.Gay2Code.GDcard_9595anemoneObjects3.length = 0;
gdjs.Gay2Code.GDcard_9595anemoneObjects4.length = 0;
gdjs.Gay2Code.GDcard_9595anemoneObjects5.length = 0;
gdjs.Gay2Code.GDcard_9595anemoneObjects6.length = 0;
gdjs.Gay2Code.GDcard_9595anemoneObjects7.length = 0;
gdjs.Gay2Code.GDcard_9595plasticbagObjects1.length = 0;
gdjs.Gay2Code.GDcard_9595plasticbagObjects2.length = 0;
gdjs.Gay2Code.GDcard_9595plasticbagObjects3.length = 0;
gdjs.Gay2Code.GDcard_9595plasticbagObjects4.length = 0;
gdjs.Gay2Code.GDcard_9595plasticbagObjects5.length = 0;
gdjs.Gay2Code.GDcard_9595plasticbagObjects6.length = 0;
gdjs.Gay2Code.GDcard_9595plasticbagObjects7.length = 0;
gdjs.Gay2Code.GDcard_9595blowfishObjects1.length = 0;
gdjs.Gay2Code.GDcard_9595blowfishObjects2.length = 0;
gdjs.Gay2Code.GDcard_9595blowfishObjects3.length = 0;
gdjs.Gay2Code.GDcard_9595blowfishObjects4.length = 0;
gdjs.Gay2Code.GDcard_9595blowfishObjects5.length = 0;
gdjs.Gay2Code.GDcard_9595blowfishObjects6.length = 0;
gdjs.Gay2Code.GDcard_9595blowfishObjects7.length = 0;
gdjs.Gay2Code.GDposition_9595placeholderObjects1.length = 0;
gdjs.Gay2Code.GDposition_9595placeholderObjects2.length = 0;
gdjs.Gay2Code.GDposition_9595placeholderObjects3.length = 0;
gdjs.Gay2Code.GDposition_9595placeholderObjects4.length = 0;
gdjs.Gay2Code.GDposition_9595placeholderObjects5.length = 0;
gdjs.Gay2Code.GDposition_9595placeholderObjects6.length = 0;
gdjs.Gay2Code.GDposition_9595placeholderObjects7.length = 0;
gdjs.Gay2Code.GDnewgame_9595buttonObjects1.length = 0;
gdjs.Gay2Code.GDnewgame_9595buttonObjects2.length = 0;
gdjs.Gay2Code.GDnewgame_9595buttonObjects3.length = 0;
gdjs.Gay2Code.GDnewgame_9595buttonObjects4.length = 0;
gdjs.Gay2Code.GDnewgame_9595buttonObjects5.length = 0;
gdjs.Gay2Code.GDnewgame_9595buttonObjects6.length = 0;
gdjs.Gay2Code.GDnewgame_9595buttonObjects7.length = 0;
gdjs.Gay2Code.GDboardObjects1.length = 0;
gdjs.Gay2Code.GDboardObjects2.length = 0;
gdjs.Gay2Code.GDboardObjects3.length = 0;
gdjs.Gay2Code.GDboardObjects4.length = 0;
gdjs.Gay2Code.GDboardObjects5.length = 0;
gdjs.Gay2Code.GDboardObjects6.length = 0;
gdjs.Gay2Code.GDboardObjects7.length = 0;
gdjs.Gay2Code.GDpairsObjects1.length = 0;
gdjs.Gay2Code.GDpairsObjects2.length = 0;
gdjs.Gay2Code.GDpairsObjects3.length = 0;
gdjs.Gay2Code.GDpairsObjects4.length = 0;
gdjs.Gay2Code.GDpairsObjects5.length = 0;
gdjs.Gay2Code.GDpairsObjects6.length = 0;
gdjs.Gay2Code.GDpairsObjects7.length = 0;
gdjs.Gay2Code.GDnewgameObjects1.length = 0;
gdjs.Gay2Code.GDnewgameObjects2.length = 0;
gdjs.Gay2Code.GDnewgameObjects3.length = 0;
gdjs.Gay2Code.GDnewgameObjects4.length = 0;
gdjs.Gay2Code.GDnewgameObjects5.length = 0;
gdjs.Gay2Code.GDnewgameObjects6.length = 0;
gdjs.Gay2Code.GDnewgameObjects7.length = 0;
gdjs.Gay2Code.GDyouwonObjects1.length = 0;
gdjs.Gay2Code.GDyouwonObjects2.length = 0;
gdjs.Gay2Code.GDyouwonObjects3.length = 0;
gdjs.Gay2Code.GDyouwonObjects4.length = 0;
gdjs.Gay2Code.GDyouwonObjects5.length = 0;
gdjs.Gay2Code.GDyouwonObjects6.length = 0;
gdjs.Gay2Code.GDyouwonObjects7.length = 0;
gdjs.Gay2Code.GDstar_9595particleObjects1.length = 0;
gdjs.Gay2Code.GDstar_9595particleObjects2.length = 0;
gdjs.Gay2Code.GDstar_9595particleObjects3.length = 0;
gdjs.Gay2Code.GDstar_9595particleObjects4.length = 0;
gdjs.Gay2Code.GDstar_9595particleObjects5.length = 0;
gdjs.Gay2Code.GDstar_9595particleObjects6.length = 0;
gdjs.Gay2Code.GDstar_9595particleObjects7.length = 0;
gdjs.Gay2Code.GDscreen_9595fadeObjects1.length = 0;
gdjs.Gay2Code.GDscreen_9595fadeObjects2.length = 0;
gdjs.Gay2Code.GDscreen_9595fadeObjects3.length = 0;
gdjs.Gay2Code.GDscreen_9595fadeObjects4.length = 0;
gdjs.Gay2Code.GDscreen_9595fadeObjects5.length = 0;
gdjs.Gay2Code.GDscreen_9595fadeObjects6.length = 0;
gdjs.Gay2Code.GDscreen_9595fadeObjects7.length = 0;
gdjs.Gay2Code.GDui_9595backgroundObjects1.length = 0;
gdjs.Gay2Code.GDui_9595backgroundObjects2.length = 0;
gdjs.Gay2Code.GDui_9595backgroundObjects3.length = 0;
gdjs.Gay2Code.GDui_9595backgroundObjects4.length = 0;
gdjs.Gay2Code.GDui_9595backgroundObjects5.length = 0;
gdjs.Gay2Code.GDui_9595backgroundObjects6.length = 0;
gdjs.Gay2Code.GDui_9595backgroundObjects7.length = 0;
gdjs.Gay2Code.GDbackgroundObjects1.length = 0;
gdjs.Gay2Code.GDbackgroundObjects2.length = 0;
gdjs.Gay2Code.GDbackgroundObjects3.length = 0;
gdjs.Gay2Code.GDbackgroundObjects4.length = 0;
gdjs.Gay2Code.GDbackgroundObjects5.length = 0;
gdjs.Gay2Code.GDbackgroundObjects6.length = 0;
gdjs.Gay2Code.GDbackgroundObjects7.length = 0;
gdjs.Gay2Code.GDrepeatObjects1.length = 0;
gdjs.Gay2Code.GDrepeatObjects2.length = 0;
gdjs.Gay2Code.GDrepeatObjects3.length = 0;
gdjs.Gay2Code.GDrepeatObjects4.length = 0;
gdjs.Gay2Code.GDrepeatObjects5.length = 0;
gdjs.Gay2Code.GDrepeatObjects6.length = 0;
gdjs.Gay2Code.GDrepeatObjects7.length = 0;
gdjs.Gay2Code.GDSigilObjects1.length = 0;
gdjs.Gay2Code.GDSigilObjects2.length = 0;
gdjs.Gay2Code.GDSigilObjects3.length = 0;
gdjs.Gay2Code.GDSigilObjects4.length = 0;
gdjs.Gay2Code.GDSigilObjects5.length = 0;
gdjs.Gay2Code.GDSigilObjects6.length = 0;
gdjs.Gay2Code.GDSigilObjects7.length = 0;

gdjs.Gay2Code.eventsList22(runtimeScene);

return;

}

gdjs['Gay2Code'] = gdjs.Gay2Code;
