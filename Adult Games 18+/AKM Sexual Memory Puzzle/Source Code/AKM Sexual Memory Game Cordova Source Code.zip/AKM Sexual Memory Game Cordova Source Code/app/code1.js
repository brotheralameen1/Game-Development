gdjs.Start_95MenuCode = {};
gdjs.Start_95MenuCode.GDBackgroundObjects1= [];
gdjs.Start_95MenuCode.GDBackgroundObjects2= [];
gdjs.Start_95MenuCode.GDStart_9595GameObjects1= [];
gdjs.Start_95MenuCode.GDStart_9595GameObjects2= [];
gdjs.Start_95MenuCode.GDDescriptionObjects1= [];
gdjs.Start_95MenuCode.GDDescriptionObjects2= [];
gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects1= [];
gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects2= [];
gdjs.Start_95MenuCode.GDSupport_9595DevObjects1= [];
gdjs.Start_95MenuCode.GDSupport_9595DevObjects2= [];
gdjs.Start_95MenuCode.GDQuitObjects1= [];
gdjs.Start_95MenuCode.GDQuitObjects2= [];
gdjs.Start_95MenuCode.GDImpInfoObjects1= [];
gdjs.Start_95MenuCode.GDImpInfoObjects2= [];
gdjs.Start_95MenuCode.GDStartObjects1= [];
gdjs.Start_95MenuCode.GDStartObjects2= [];
gdjs.Start_95MenuCode.GDDescObjects1= [];
gdjs.Start_95MenuCode.GDDescObjects2= [];
gdjs.Start_95MenuCode.GDHow_9595To_9595Play2Objects1= [];
gdjs.Start_95MenuCode.GDHow_9595To_9595Play2Objects2= [];
gdjs.Start_95MenuCode.GDDevSuppObjects1= [];
gdjs.Start_95MenuCode.GDDevSuppObjects2= [];
gdjs.Start_95MenuCode.GDExitObjects1= [];
gdjs.Start_95MenuCode.GDExitObjects2= [];
gdjs.Start_95MenuCode.GDImpDescrObjects1= [];
gdjs.Start_95MenuCode.GDImpDescrObjects2= [];


gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDStart_95959595GameObjects1Objects = Hashtable.newFrom({"Start_Game": gdjs.Start_95MenuCode.GDStart_9595GameObjects1});
gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDHow_95959595To_95959595PlayObjects1Objects = Hashtable.newFrom({"How_To_Play": gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects1});
gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDSupport_95959595DevObjects1Objects = Hashtable.newFrom({"Support_Dev": gdjs.Start_95MenuCode.GDSupport_9595DevObjects1});
gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDQuitObjects1Objects = Hashtable.newFrom({"Quit": gdjs.Start_95MenuCode.GDQuitObjects1});
gdjs.Start_95MenuCode.eventsList0 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Start_Game"), gdjs.Start_95MenuCode.GDStart_9595GameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDStart_95959595GameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Sexuality", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("How_To_Play"), gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDHow_95959595To_95959595PlayObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "How_to_Play", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Support_Dev"), gdjs.Start_95MenuCode.GDSupport_9595DevObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDSupport_95959595DevObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "DevSupp", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quit"), gdjs.Start_95MenuCode.GDQuitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDQuitObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Start_95MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Start_95MenuCode.GDBackgroundObjects1.length = 0;
gdjs.Start_95MenuCode.GDBackgroundObjects2.length = 0;
gdjs.Start_95MenuCode.GDStart_9595GameObjects1.length = 0;
gdjs.Start_95MenuCode.GDStart_9595GameObjects2.length = 0;
gdjs.Start_95MenuCode.GDDescriptionObjects1.length = 0;
gdjs.Start_95MenuCode.GDDescriptionObjects2.length = 0;
gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects1.length = 0;
gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects2.length = 0;
gdjs.Start_95MenuCode.GDSupport_9595DevObjects1.length = 0;
gdjs.Start_95MenuCode.GDSupport_9595DevObjects2.length = 0;
gdjs.Start_95MenuCode.GDQuitObjects1.length = 0;
gdjs.Start_95MenuCode.GDQuitObjects2.length = 0;
gdjs.Start_95MenuCode.GDImpInfoObjects1.length = 0;
gdjs.Start_95MenuCode.GDImpInfoObjects2.length = 0;
gdjs.Start_95MenuCode.GDStartObjects1.length = 0;
gdjs.Start_95MenuCode.GDStartObjects2.length = 0;
gdjs.Start_95MenuCode.GDDescObjects1.length = 0;
gdjs.Start_95MenuCode.GDDescObjects2.length = 0;
gdjs.Start_95MenuCode.GDHow_9595To_9595Play2Objects1.length = 0;
gdjs.Start_95MenuCode.GDHow_9595To_9595Play2Objects2.length = 0;
gdjs.Start_95MenuCode.GDDevSuppObjects1.length = 0;
gdjs.Start_95MenuCode.GDDevSuppObjects2.length = 0;
gdjs.Start_95MenuCode.GDExitObjects1.length = 0;
gdjs.Start_95MenuCode.GDExitObjects2.length = 0;
gdjs.Start_95MenuCode.GDImpDescrObjects1.length = 0;
gdjs.Start_95MenuCode.GDImpDescrObjects2.length = 0;

gdjs.Start_95MenuCode.eventsList0(runtimeScene);

return;

}

gdjs['Start_95MenuCode'] = gdjs.Start_95MenuCode;
