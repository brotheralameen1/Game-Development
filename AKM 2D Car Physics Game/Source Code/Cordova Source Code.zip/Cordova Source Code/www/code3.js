gdjs.How_95To_95PlayCode = {};
gdjs.How_95To_95PlayCode.GDInstrObjects1= [];
gdjs.How_95To_95PlayCode.GDInstrObjects2= [];
gdjs.How_95To_95PlayCode.GDHTPObjects1= [];
gdjs.How_95To_95PlayCode.GDHTPObjects2= [];
gdjs.How_95To_95PlayCode.GDInstructionsObjects1= [];
gdjs.How_95To_95PlayCode.GDInstructionsObjects2= [];
gdjs.How_95To_95PlayCode.GDStart_9595MenuObjects1= [];
gdjs.How_95To_95PlayCode.GDStart_9595MenuObjects2= [];
gdjs.How_95To_95PlayCode.GDQuitObjects1= [];
gdjs.How_95To_95PlayCode.GDQuitObjects2= [];
gdjs.How_95To_95PlayCode.GDHTP2Objects1= [];
gdjs.How_95To_95PlayCode.GDHTP2Objects2= [];
gdjs.How_95To_95PlayCode.GDQuit2Objects1= [];
gdjs.How_95To_95PlayCode.GDQuit2Objects2= [];
gdjs.How_95To_95PlayCode.GDMain_9595MenuObjects1= [];
gdjs.How_95To_95PlayCode.GDMain_9595MenuObjects2= [];


gdjs.How_95To_95PlayCode.mapOfGDgdjs_9546How_959595To_959595PlayCode_9546GDStart_95959595MenuObjects1Objects = Hashtable.newFrom({"Start_Menu": gdjs.How_95To_95PlayCode.GDStart_9595MenuObjects1});
gdjs.How_95To_95PlayCode.mapOfGDgdjs_9546How_959595To_959595PlayCode_9546GDQuitObjects1Objects = Hashtable.newFrom({"Quit": gdjs.How_95To_95PlayCode.GDQuitObjects1});
gdjs.How_95To_95PlayCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Start_Menu"), gdjs.How_95To_95PlayCode.GDStart_9595MenuObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.How_95To_95PlayCode.mapOfGDgdjs_9546How_959595To_959595PlayCode_9546GDStart_95959595MenuObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Start_Menu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quit"), gdjs.How_95To_95PlayCode.GDQuitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.How_95To_95PlayCode.mapOfGDgdjs_9546How_959595To_959595PlayCode_9546GDQuitObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.How_95To_95PlayCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.How_95To_95PlayCode.GDInstrObjects1.length = 0;
gdjs.How_95To_95PlayCode.GDInstrObjects2.length = 0;
gdjs.How_95To_95PlayCode.GDHTPObjects1.length = 0;
gdjs.How_95To_95PlayCode.GDHTPObjects2.length = 0;
gdjs.How_95To_95PlayCode.GDInstructionsObjects1.length = 0;
gdjs.How_95To_95PlayCode.GDInstructionsObjects2.length = 0;
gdjs.How_95To_95PlayCode.GDStart_9595MenuObjects1.length = 0;
gdjs.How_95To_95PlayCode.GDStart_9595MenuObjects2.length = 0;
gdjs.How_95To_95PlayCode.GDQuitObjects1.length = 0;
gdjs.How_95To_95PlayCode.GDQuitObjects2.length = 0;
gdjs.How_95To_95PlayCode.GDHTP2Objects1.length = 0;
gdjs.How_95To_95PlayCode.GDHTP2Objects2.length = 0;
gdjs.How_95To_95PlayCode.GDQuit2Objects1.length = 0;
gdjs.How_95To_95PlayCode.GDQuit2Objects2.length = 0;
gdjs.How_95To_95PlayCode.GDMain_9595MenuObjects1.length = 0;
gdjs.How_95To_95PlayCode.GDMain_9595MenuObjects2.length = 0;

gdjs.How_95To_95PlayCode.eventsList0(runtimeScene);

return;

}

gdjs['How_95To_95PlayCode'] = gdjs.How_95To_95PlayCode;
