gdjs.SplashCode = {};
gdjs.SplashCode.GDLogoObjects1= [];
gdjs.SplashCode.GDLogoObjects2= [];


gdjs.SplashCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Logo"), gdjs.SplashCode.GDLogoObjects1);
{for(var i = 0, len = gdjs.SplashCode.GDLogoObjects1.length ;i < len;++i) {
    gdjs.SplashCode.GDLogoObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Logo"), gdjs.SplashCode.GDLogoObjects1);
{for(var i = 0, len = gdjs.SplashCode.GDLogoObjects1.length ;i < len;++i) {
    gdjs.SplashCode.GDLogoObjects1[i].getBehavior("Opacity").setOpacity(gdjs.SplashCode.GDLogoObjects1[i].getBehavior("Opacity").getOpacity() + (gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene) * 10));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Logo"), gdjs.SplashCode.GDLogoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SplashCode.GDLogoObjects1.length;i<l;++i) {
    if ( gdjs.SplashCode.GDLogoObjects1[i].getBehavior("Opacity").getOpacity() >= 100 ) {
        isConditionTrue_0 = true;
        gdjs.SplashCode.GDLogoObjects1[k] = gdjs.SplashCode.GDLogoObjects1[i];
        ++k;
    }
}
gdjs.SplashCode.GDLogoObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Start_Menu", false);
}}

}


};

gdjs.SplashCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.SplashCode.GDLogoObjects1.length = 0;
gdjs.SplashCode.GDLogoObjects2.length = 0;

gdjs.SplashCode.eventsList0(runtimeScene);

return;

}

gdjs['SplashCode'] = gdjs.SplashCode;
