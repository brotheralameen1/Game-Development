gdjs.GameCode = {};
gdjs.GameCode.GDCarBodyObjects1= [];
gdjs.GameCode.GDCarBodyObjects2= [];
gdjs.GameCode.GDCarBodyObjects3= [];
gdjs.GameCode.GDFrontWheelObjects1= [];
gdjs.GameCode.GDFrontWheelObjects2= [];
gdjs.GameCode.GDFrontWheelObjects3= [];
gdjs.GameCode.GDBackWheelObjects1= [];
gdjs.GameCode.GDBackWheelObjects2= [];
gdjs.GameCode.GDBackWheelObjects3= [];
gdjs.GameCode.GDPlatformObjects1= [];
gdjs.GameCode.GDPlatformObjects2= [];
gdjs.GameCode.GDPlatformObjects3= [];
gdjs.GameCode.GDBoxObjects1= [];
gdjs.GameCode.GDBoxObjects2= [];
gdjs.GameCode.GDBoxObjects3= [];
gdjs.GameCode.GDRestartLevelObjects1= [];
gdjs.GameCode.GDRestartLevelObjects2= [];
gdjs.GameCode.GDRestartLevelObjects3= [];
gdjs.GameCode.GDRestartObjects1= [];
gdjs.GameCode.GDRestartObjects2= [];
gdjs.GameCode.GDRestartObjects3= [];
gdjs.GameCode.GDPillarObjects1= [];
gdjs.GameCode.GDPillarObjects2= [];
gdjs.GameCode.GDPillarObjects3= [];
gdjs.GameCode.GDFrontLightObjects1= [];
gdjs.GameCode.GDFrontLightObjects2= [];
gdjs.GameCode.GDFrontLightObjects3= [];
gdjs.GameCode.GDBackLightObjects1= [];
gdjs.GameCode.GDBackLightObjects2= [];
gdjs.GameCode.GDBackLightObjects3= [];


gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDFrontWheelObjects1Objects = Hashtable.newFrom({"FrontWheel": gdjs.GameCode.GDFrontWheelObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlatformObjects1ObjectsGDgdjs_9546GameCode_9546GDBoxObjects1Objects = Hashtable.newFrom({"Platform": gdjs.GameCode.GDPlatformObjects1, "Box": gdjs.GameCode.GDBoxObjects1});
gdjs.GameCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDFrontWheelObjects1, gdjs.GameCode.GDFrontWheelObjects2);

{for(var i = 0, len = gdjs.GameCode.GDFrontWheelObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDFrontWheelObjects2[i].getBehavior("Physics2").setLinearVelocityX(gdjs.GameCode.GDFrontWheelObjects2[i].getBehavior("Physics2").getLinearVelocityX() - (50));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDFrontWheelObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDFrontWheelObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDFrontWheelObjects1[i].getBehavior("Physics2").setLinearVelocityX(gdjs.GameCode.GDFrontWheelObjects1[i].getBehavior("Physics2").getLinearVelocityX() + (100));
}
}}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDFrontWheelObjects1Objects = Hashtable.newFrom({"FrontWheel": gdjs.GameCode.GDFrontWheelObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlatformObjects1ObjectsGDgdjs_9546GameCode_9546GDBoxObjects1Objects = Hashtable.newFrom({"Platform": gdjs.GameCode.GDPlatformObjects1, "Box": gdjs.GameCode.GDBoxObjects1});
gdjs.GameCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CarBody"), gdjs.GameCode.GDCarBodyObjects2);
{for(var i = 0, len = gdjs.GameCode.GDCarBodyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDCarBodyObjects2[i].getBehavior("Physics2").setAngularVelocity(gdjs.GameCode.GDCarBodyObjects2[i].getBehavior("Physics2").getAngularVelocity() - (3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CarBody"), gdjs.GameCode.GDCarBodyObjects1);
{for(var i = 0, len = gdjs.GameCode.GDCarBodyObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDCarBodyObjects1[i].getBehavior("Physics2").setAngularVelocity(gdjs.GameCode.GDCarBodyObjects1[i].getBehavior("Physics2").getAngularVelocity() + (3));
}
}}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDCarBodyObjects1Objects = Hashtable.newFrom({"CarBody": gdjs.GameCode.GDCarBodyObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDRestartLevelObjects1Objects = Hashtable.newFrom({"RestartLevel": gdjs.GameCode.GDRestartLevelObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDRestartObjects1Objects = Hashtable.newFrom({"Restart": gdjs.GameCode.GDRestartObjects1});
gdjs.GameCode.eventsList2 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 0.4, "", 0);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("CarBody"), gdjs.GameCode.GDCarBodyObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), (( gdjs.GameCode.GDCarBodyObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDCarBodyObjects1[0].getPointX("")), 0.05), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), (( gdjs.GameCode.GDCarBodyObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDCarBodyObjects1[0].getPointY("")), 0.05), "", 0);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BackWheel"), gdjs.GameCode.GDBackWheelObjects1);
gdjs.copyArray(runtimeScene.getObjects("CarBody"), gdjs.GameCode.GDCarBodyObjects1);
gdjs.copyArray(runtimeScene.getObjects("FrontWheel"), gdjs.GameCode.GDFrontWheelObjects1);
{for(var i = 0, len = gdjs.GameCode.GDFrontWheelObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDFrontWheelObjects1[i].getBehavior("Physics2").addWheelJoint((gdjs.GameCode.GDFrontWheelObjects1[i].getPointX("")), (gdjs.GameCode.GDFrontWheelObjects1[i].getPointY("")), (gdjs.GameCode.GDCarBodyObjects1.length !== 0 ? gdjs.GameCode.GDCarBodyObjects1[0] : null), (( gdjs.GameCode.GDCarBodyObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDCarBodyObjects1[0].getPointX("FrontWheel")), (( gdjs.GameCode.GDCarBodyObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDCarBodyObjects1[0].getPointY("FrontWheel")), 0, 10, 1, false, 0, 0, false, gdjs.VariablesContainer.badVariable);
}
}{for(var i = 0, len = gdjs.GameCode.GDBackWheelObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDBackWheelObjects1[i].getBehavior("Physics2").addWheelJoint((gdjs.GameCode.GDBackWheelObjects1[i].getPointX("")), (gdjs.GameCode.GDBackWheelObjects1[i].getPointY("")), (gdjs.GameCode.GDCarBodyObjects1.length !== 0 ? gdjs.GameCode.GDCarBodyObjects1[0] : null), (( gdjs.GameCode.GDCarBodyObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDCarBodyObjects1[0].getPointX("BackWheel")), (( gdjs.GameCode.GDCarBodyObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDCarBodyObjects1[0].getPointY("BackWheel")), 0, 10, 1, false, 0, 0, false, gdjs.VariablesContainer.badVariable);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Box"), gdjs.GameCode.GDBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("FrontWheel"), gdjs.GameCode.GDFrontWheelObjects1);
gdjs.copyArray(runtimeScene.getObjects("Platform"), gdjs.GameCode.GDPlatformObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.objectsCollide(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDFrontWheelObjects1Objects, "Physics2", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlatformObjects1ObjectsGDgdjs_9546GameCode_9546GDBoxObjects1Objects, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList0(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(8345836);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CarBody"), gdjs.GameCode.GDCarBodyObjects1);
{for(var i = 0, len = gdjs.GameCode.GDCarBodyObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDCarBodyObjects1[i].getBehavior("Physics2").setLinearVelocityY(-(1500));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Box"), gdjs.GameCode.GDBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("FrontWheel"), gdjs.GameCode.GDFrontWheelObjects1);
gdjs.copyArray(runtimeScene.getObjects("Platform"), gdjs.GameCode.GDPlatformObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.objectsCollide(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDFrontWheelObjects1Objects, "Physics2", gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlatformObjects1ObjectsGDgdjs_9546GameCode_9546GDBoxObjects1Objects, true);
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList1(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("RestartLevel"), gdjs.GameCode.GDRestartLevelObjects1);
{for(var i = 0, len = gdjs.GameCode.GDRestartLevelObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDRestartLevelObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CarBody"), gdjs.GameCode.GDCarBodyObjects1);
gdjs.copyArray(runtimeScene.getObjects("RestartLevel"), gdjs.GameCode.GDRestartLevelObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDCarBodyObjects1Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDRestartLevelObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Game");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Restart"), gdjs.GameCode.GDRestartObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDRestartObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(8369436);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Game");
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BackLight"), gdjs.GameCode.GDBackLightObjects1);
gdjs.copyArray(runtimeScene.getObjects("CarBody"), gdjs.GameCode.GDCarBodyObjects1);
gdjs.copyArray(runtimeScene.getObjects("FrontLight"), gdjs.GameCode.GDFrontLightObjects1);
{for(var i = 0, len = gdjs.GameCode.GDBackLightObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDBackLightObjects1[i].setPosition((( gdjs.GameCode.GDCarBodyObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDCarBodyObjects1[0].getPointX("BackLight")),(( gdjs.GameCode.GDCarBodyObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDCarBodyObjects1[0].getPointY("BackLight")));
}
}{for(var i = 0, len = gdjs.GameCode.GDFrontLightObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDFrontLightObjects1[i].setPosition((( gdjs.GameCode.GDCarBodyObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDCarBodyObjects1[0].getPointX("FrontLight")),(( gdjs.GameCode.GDCarBodyObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDCarBodyObjects1[0].getPointY("FrontLight")));
}
}}

}


};

gdjs.GameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameCode.GDCarBodyObjects1.length = 0;
gdjs.GameCode.GDCarBodyObjects2.length = 0;
gdjs.GameCode.GDCarBodyObjects3.length = 0;
gdjs.GameCode.GDFrontWheelObjects1.length = 0;
gdjs.GameCode.GDFrontWheelObjects2.length = 0;
gdjs.GameCode.GDFrontWheelObjects3.length = 0;
gdjs.GameCode.GDBackWheelObjects1.length = 0;
gdjs.GameCode.GDBackWheelObjects2.length = 0;
gdjs.GameCode.GDBackWheelObjects3.length = 0;
gdjs.GameCode.GDPlatformObjects1.length = 0;
gdjs.GameCode.GDPlatformObjects2.length = 0;
gdjs.GameCode.GDPlatformObjects3.length = 0;
gdjs.GameCode.GDBoxObjects1.length = 0;
gdjs.GameCode.GDBoxObjects2.length = 0;
gdjs.GameCode.GDBoxObjects3.length = 0;
gdjs.GameCode.GDRestartLevelObjects1.length = 0;
gdjs.GameCode.GDRestartLevelObjects2.length = 0;
gdjs.GameCode.GDRestartLevelObjects3.length = 0;
gdjs.GameCode.GDRestartObjects1.length = 0;
gdjs.GameCode.GDRestartObjects2.length = 0;
gdjs.GameCode.GDRestartObjects3.length = 0;
gdjs.GameCode.GDPillarObjects1.length = 0;
gdjs.GameCode.GDPillarObjects2.length = 0;
gdjs.GameCode.GDPillarObjects3.length = 0;
gdjs.GameCode.GDFrontLightObjects1.length = 0;
gdjs.GameCode.GDFrontLightObjects2.length = 0;
gdjs.GameCode.GDFrontLightObjects3.length = 0;
gdjs.GameCode.GDBackLightObjects1.length = 0;
gdjs.GameCode.GDBackLightObjects2.length = 0;
gdjs.GameCode.GDBackLightObjects3.length = 0;

gdjs.GameCode.eventsList2(runtimeScene);

return;

}

gdjs['GameCode'] = gdjs.GameCode;
