gdjs.ContributeCode = {};
gdjs.ContributeCode.GDInstObjects1= [];
gdjs.ContributeCode.GDInstObjects2= [];
gdjs.ContributeCode.GDContribObjects1= [];
gdjs.ContributeCode.GDContribObjects2= [];
gdjs.ContributeCode.GDCryptoObjects1= [];
gdjs.ContributeCode.GDCryptoObjects2= [];
gdjs.ContributeCode.GDYouTubeObjects1= [];
gdjs.ContributeCode.GDYouTubeObjects2= [];
gdjs.ContributeCode.GDQuitObjects1= [];
gdjs.ContributeCode.GDQuitObjects2= [];
gdjs.ContributeCode.GDStart_9595MenuObjects1= [];
gdjs.ContributeCode.GDStart_9595MenuObjects2= [];
gdjs.ContributeCode.GDCrypto2Objects1= [];
gdjs.ContributeCode.GDCrypto2Objects2= [];
gdjs.ContributeCode.GDYouTube2Objects1= [];
gdjs.ContributeCode.GDYouTube2Objects2= [];
gdjs.ContributeCode.GDStart_9595Menu2Objects1= [];
gdjs.ContributeCode.GDStart_9595Menu2Objects2= [];
gdjs.ContributeCode.GDQuit_9595GameObjects1= [];
gdjs.ContributeCode.GDQuit_9595GameObjects2= [];


gdjs.ContributeCode.mapOfGDgdjs_9546ContributeCode_9546GDCryptoObjects1Objects = Hashtable.newFrom({"Crypto": gdjs.ContributeCode.GDCryptoObjects1});
gdjs.ContributeCode.mapOfGDgdjs_9546ContributeCode_9546GDYouTubeObjects1Objects = Hashtable.newFrom({"YouTube": gdjs.ContributeCode.GDYouTubeObjects1});
gdjs.ContributeCode.mapOfGDgdjs_9546ContributeCode_9546GDStart_95959595MenuObjects1Objects = Hashtable.newFrom({"Start_Menu": gdjs.ContributeCode.GDStart_9595MenuObjects1});
gdjs.ContributeCode.mapOfGDgdjs_9546ContributeCode_9546GDQuitObjects1Objects = Hashtable.newFrom({"Quit": gdjs.ContributeCode.GDQuitObjects1});
gdjs.ContributeCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Crypto"), gdjs.ContributeCode.GDCryptoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ContributeCode.mapOfGDgdjs_9546ContributeCode_9546GDCryptoObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://pastebin.com/hvswspz1", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("YouTube"), gdjs.ContributeCode.GDYouTubeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ContributeCode.mapOfGDgdjs_9546ContributeCode_9546GDYouTubeObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://youtube.com/channel/UCRmZnjgfrD7al_h-cyOdQLA", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Start_Menu"), gdjs.ContributeCode.GDStart_9595MenuObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ContributeCode.mapOfGDgdjs_9546ContributeCode_9546GDStart_95959595MenuObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Start_Menu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quit"), gdjs.ContributeCode.GDQuitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ContributeCode.mapOfGDgdjs_9546ContributeCode_9546GDQuitObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.ContributeCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ContributeCode.GDInstObjects1.length = 0;
gdjs.ContributeCode.GDInstObjects2.length = 0;
gdjs.ContributeCode.GDContribObjects1.length = 0;
gdjs.ContributeCode.GDContribObjects2.length = 0;
gdjs.ContributeCode.GDCryptoObjects1.length = 0;
gdjs.ContributeCode.GDCryptoObjects2.length = 0;
gdjs.ContributeCode.GDYouTubeObjects1.length = 0;
gdjs.ContributeCode.GDYouTubeObjects2.length = 0;
gdjs.ContributeCode.GDQuitObjects1.length = 0;
gdjs.ContributeCode.GDQuitObjects2.length = 0;
gdjs.ContributeCode.GDStart_9595MenuObjects1.length = 0;
gdjs.ContributeCode.GDStart_9595MenuObjects2.length = 0;
gdjs.ContributeCode.GDCrypto2Objects1.length = 0;
gdjs.ContributeCode.GDCrypto2Objects2.length = 0;
gdjs.ContributeCode.GDYouTube2Objects1.length = 0;
gdjs.ContributeCode.GDYouTube2Objects2.length = 0;
gdjs.ContributeCode.GDStart_9595Menu2Objects1.length = 0;
gdjs.ContributeCode.GDStart_9595Menu2Objects2.length = 0;
gdjs.ContributeCode.GDQuit_9595GameObjects1.length = 0;
gdjs.ContributeCode.GDQuit_9595GameObjects2.length = 0;

gdjs.ContributeCode.eventsList0(runtimeScene);

return;

}

gdjs['ContributeCode'] = gdjs.ContributeCode;
