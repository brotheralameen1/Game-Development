gdjs.Start_95MenuCode = {};
gdjs.Start_95MenuCode.GDIntroObjects1= [];
gdjs.Start_95MenuCode.GDIntroObjects2= [];
gdjs.Start_95MenuCode.GDIntro1Objects1= [];
gdjs.Start_95MenuCode.GDIntro1Objects2= [];
gdjs.Start_95MenuCode.GDStartGameObjects1= [];
gdjs.Start_95MenuCode.GDStartGameObjects2= [];
gdjs.Start_95MenuCode.GDContributeObjects1= [];
gdjs.Start_95MenuCode.GDContributeObjects2= [];
gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects1= [];
gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects2= [];
gdjs.Start_95MenuCode.GDQuit_9595GameObjects1= [];
gdjs.Start_95MenuCode.GDQuit_9595GameObjects2= [];
gdjs.Start_95MenuCode.GDStartGame2Objects1= [];
gdjs.Start_95MenuCode.GDStartGame2Objects2= [];
gdjs.Start_95MenuCode.GDHow_9595To_9595Play2Objects1= [];
gdjs.Start_95MenuCode.GDHow_9595To_9595Play2Objects2= [];
gdjs.Start_95MenuCode.GDContribObjects1= [];
gdjs.Start_95MenuCode.GDContribObjects2= [];
gdjs.Start_95MenuCode.GDQuit_9595Game2Objects1= [];
gdjs.Start_95MenuCode.GDQuit_9595Game2Objects2= [];


gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDStartGameObjects1Objects = Hashtable.newFrom({"StartGame": gdjs.Start_95MenuCode.GDStartGameObjects1});
gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDHow_95959595To_95959595PlayObjects1Objects = Hashtable.newFrom({"How_To_Play": gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects1});
gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDContributeObjects1Objects = Hashtable.newFrom({"Contribute": gdjs.Start_95MenuCode.GDContributeObjects1});
gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDQuit_95959595GameObjects1Objects = Hashtable.newFrom({"Quit_Game": gdjs.Start_95MenuCode.GDQuit_9595GameObjects1});
gdjs.Start_95MenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("StartGame"), gdjs.Start_95MenuCode.GDStartGameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDStartGameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("How_To_Play"), gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDHow_95959595To_95959595PlayObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "How_To_Play", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Contribute"), gdjs.Start_95MenuCode.GDContributeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDContributeObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Contribute", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quit_Game"), gdjs.Start_95MenuCode.GDQuit_9595GameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDQuit_95959595GameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Start_95MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Start_95MenuCode.GDIntroObjects1.length = 0;
gdjs.Start_95MenuCode.GDIntroObjects2.length = 0;
gdjs.Start_95MenuCode.GDIntro1Objects1.length = 0;
gdjs.Start_95MenuCode.GDIntro1Objects2.length = 0;
gdjs.Start_95MenuCode.GDStartGameObjects1.length = 0;
gdjs.Start_95MenuCode.GDStartGameObjects2.length = 0;
gdjs.Start_95MenuCode.GDContributeObjects1.length = 0;
gdjs.Start_95MenuCode.GDContributeObjects2.length = 0;
gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects1.length = 0;
gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects2.length = 0;
gdjs.Start_95MenuCode.GDQuit_9595GameObjects1.length = 0;
gdjs.Start_95MenuCode.GDQuit_9595GameObjects2.length = 0;
gdjs.Start_95MenuCode.GDStartGame2Objects1.length = 0;
gdjs.Start_95MenuCode.GDStartGame2Objects2.length = 0;
gdjs.Start_95MenuCode.GDHow_9595To_9595Play2Objects1.length = 0;
gdjs.Start_95MenuCode.GDHow_9595To_9595Play2Objects2.length = 0;
gdjs.Start_95MenuCode.GDContribObjects1.length = 0;
gdjs.Start_95MenuCode.GDContribObjects2.length = 0;
gdjs.Start_95MenuCode.GDQuit_9595Game2Objects1.length = 0;
gdjs.Start_95MenuCode.GDQuit_9595Game2Objects2.length = 0;

gdjs.Start_95MenuCode.eventsList0(runtimeScene);

return;

}

gdjs['Start_95MenuCode'] = gdjs.Start_95MenuCode;
