gdjs.How_95To_95PlayCode = {};
gdjs.How_95To_95PlayCode.GDDescriptionObjects1= [];
gdjs.How_95To_95PlayCode.GDDescriptionObjects2= [];
gdjs.How_95To_95PlayCode.GDhow_9595to_9595playObjects1= [];
gdjs.How_95To_95PlayCode.GDhow_9595to_9595playObjects2= [];
gdjs.How_95To_95PlayCode.GDBackObjects1= [];
gdjs.How_95To_95PlayCode.GDBackObjects2= [];
gdjs.How_95To_95PlayCode.GDQuitObjects1= [];
gdjs.How_95To_95PlayCode.GDQuitObjects2= [];
gdjs.How_95To_95PlayCode.GDBack1Objects1= [];
gdjs.How_95To_95PlayCode.GDBack1Objects2= [];
gdjs.How_95To_95PlayCode.GDExitObjects1= [];
gdjs.How_95To_95PlayCode.GDExitObjects2= [];
gdjs.How_95To_95PlayCode.GDDesc1Objects1= [];
gdjs.How_95To_95PlayCode.GDDesc1Objects2= [];
gdjs.How_95To_95PlayCode.GDInstructionsObjects1= [];
gdjs.How_95To_95PlayCode.GDInstructionsObjects2= [];


gdjs.How_95To_95PlayCode.mapOfGDgdjs_9546How_959595To_959595PlayCode_9546GDBackObjects1Objects = Hashtable.newFrom({"Back": gdjs.How_95To_95PlayCode.GDBackObjects1});
gdjs.How_95To_95PlayCode.mapOfGDgdjs_9546How_959595To_959595PlayCode_9546GDQuitObjects1Objects = Hashtable.newFrom({"Quit": gdjs.How_95To_95PlayCode.GDQuitObjects1});
gdjs.How_95To_95PlayCode.eventsList0 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.How_95To_95PlayCode.GDBackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.How_95To_95PlayCode.mapOfGDgdjs_9546How_959595To_959595PlayCode_9546GDBackObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Start_Menu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quit"), gdjs.How_95To_95PlayCode.GDQuitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.How_95To_95PlayCode.mapOfGDgdjs_9546How_959595To_959595PlayCode_9546GDQuitObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


};

gdjs.How_95To_95PlayCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.How_95To_95PlayCode.GDDescriptionObjects1.length = 0;
gdjs.How_95To_95PlayCode.GDDescriptionObjects2.length = 0;
gdjs.How_95To_95PlayCode.GDhow_9595to_9595playObjects1.length = 0;
gdjs.How_95To_95PlayCode.GDhow_9595to_9595playObjects2.length = 0;
gdjs.How_95To_95PlayCode.GDBackObjects1.length = 0;
gdjs.How_95To_95PlayCode.GDBackObjects2.length = 0;
gdjs.How_95To_95PlayCode.GDQuitObjects1.length = 0;
gdjs.How_95To_95PlayCode.GDQuitObjects2.length = 0;
gdjs.How_95To_95PlayCode.GDBack1Objects1.length = 0;
gdjs.How_95To_95PlayCode.GDBack1Objects2.length = 0;
gdjs.How_95To_95PlayCode.GDExitObjects1.length = 0;
gdjs.How_95To_95PlayCode.GDExitObjects2.length = 0;
gdjs.How_95To_95PlayCode.GDDesc1Objects1.length = 0;
gdjs.How_95To_95PlayCode.GDDesc1Objects2.length = 0;
gdjs.How_95To_95PlayCode.GDInstructionsObjects1.length = 0;
gdjs.How_95To_95PlayCode.GDInstructionsObjects2.length = 0;

gdjs.How_95To_95PlayCode.eventsList0(runtimeScene);

return;

}

gdjs['How_95To_95PlayCode'] = gdjs.How_95To_95PlayCode;
