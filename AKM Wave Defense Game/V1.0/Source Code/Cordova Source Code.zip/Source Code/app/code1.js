gdjs.GameCode = {};
gdjs.GameCode.GDfloorObjects1= [];
gdjs.GameCode.GDfloorObjects2= [];
gdjs.GameCode.GDPlayerObjects1= [];
gdjs.GameCode.GDPlayerObjects2= [];
gdjs.GameCode.GDGunObjects1= [];
gdjs.GameCode.GDGunObjects2= [];
gdjs.GameCode.GDBulletObjects1= [];
gdjs.GameCode.GDBulletObjects2= [];
gdjs.GameCode.GDEnemyObjects1= [];
gdjs.GameCode.GDEnemyObjects2= [];
gdjs.GameCode.GDCenterObjects1= [];
gdjs.GameCode.GDCenterObjects2= [];
gdjs.GameCode.GDSpawnPointsObjects1= [];
gdjs.GameCode.GDSpawnPointsObjects2= [];
gdjs.GameCode.GDCOSObjects1= [];
gdjs.GameCode.GDCOSObjects2= [];


gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.GameCode.GDBulletObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.GameCode.GDBulletObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.GameCode.GDPlayerObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.GameCode.GDBulletObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.GameCode.GDEnemyObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSpawnPointsObjects1Objects = Hashtable.newFrom({"SpawnPoints": gdjs.GameCode.GDSpawnPointsObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.GameCode.GDEnemyObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.GameCode.GDEnemyObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDCenterObjects1Objects = Hashtable.newFrom({"Center": gdjs.GameCode.GDCenterObjects1});
gdjs.GameCode.eventsList0 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("floor"), gdjs.GameCode.GDfloorObjects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.GameCode.GDfloorObjects1.length !== 0 ? gdjs.GameCode.GDfloorObjects1[0] : null), true, "", 0);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPlayerObjects1[k] = gdjs.GameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Run");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPlayerObjects1[k] = gdjs.GameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDPlayerObjects1[i].getX() < gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPlayerObjects1[k] = gdjs.GameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.GameCode.GDGunObjects1);
/* Reuse gdjs.GameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}{for(var i = 0, len = gdjs.GameCode.GDGunObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDGunObjects1[i].getBehavior("Flippable").flipY(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDPlayerObjects1[i].getX() > gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPlayerObjects1[k] = gdjs.GameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.GameCode.GDGunObjects1);
/* Reuse gdjs.GameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(true);
}
}{for(var i = 0, len = gdjs.GameCode.GDGunObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDGunObjects1[i].getBehavior("Flippable").flipY(true);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.GameCode.GDGunObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.GameCode.GDGunObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDGunObjects1[i].setPosition((( gdjs.GameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects1[0].getPointX("Gun")),(( gdjs.GameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects1[0].getPointY("Gun")));
}
}{for(var i = 0, len = gdjs.GameCode.GDGunObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDGunObjects1[i].rotateTowardPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 0, runtimeScene);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.GameCode.GDGunObjects1);
gdjs.GameCode.GDBulletObjects1.length = 0;

{for(var i = 0, len = gdjs.GameCode.GDGunObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDGunObjects1[i].getBehavior("FireBullet").Fire((gdjs.GameCode.GDGunObjects1[i].getPointX("Bullet")), (gdjs.GameCode.GDGunObjects1[i].getPointY("Bullet")), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBulletObjects1Objects, (gdjs.GameCode.GDGunObjects1[i].getAngle()), 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.GameCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBulletObjects1Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects1Objects, 400, true);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBulletObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.GameCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.GameCode.GDEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBulletObjects1Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBulletObjects1 */
/* Reuse gdjs.GameCode.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDEnemyObjects1[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.GameCode.GDEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDEnemyObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDEnemyObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDEnemyObjects1[k] = gdjs.GameCode.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDEnemyObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDEnemyObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Enemy_Spawn");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SpawnPoints"), gdjs.GameCode.GDSpawnPointsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Enemy_Spawn") > 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSpawnPointsObjects1Objects);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.GameCode.GDCenterObjects1);
/* Reuse gdjs.GameCode.GDSpawnPointsObjects1 */
gdjs.GameCode.GDEnemyObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDEnemyObjects1Objects, (( gdjs.GameCode.GDSpawnPointsObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDSpawnPointsObjects1[0].getPointX("")), (( gdjs.GameCode.GDSpawnPointsObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDSpawnPointsObjects1[0].getPointY("")), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Enemy_Spawn");
}{for(var i = 0, len = gdjs.GameCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDEnemyObjects1[i].addForceTowardObject((gdjs.GameCode.GDCenterObjects1.length !== 0 ? gdjs.GameCode.GDCenterObjects1[0] : null), 20, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.GameCode.GDCenterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.GameCode.GDEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDEnemyObjects1Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDCenterObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game_Over", false);
}}

}


};

gdjs.GameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameCode.GDfloorObjects1.length = 0;
gdjs.GameCode.GDfloorObjects2.length = 0;
gdjs.GameCode.GDPlayerObjects1.length = 0;
gdjs.GameCode.GDPlayerObjects2.length = 0;
gdjs.GameCode.GDGunObjects1.length = 0;
gdjs.GameCode.GDGunObjects2.length = 0;
gdjs.GameCode.GDBulletObjects1.length = 0;
gdjs.GameCode.GDBulletObjects2.length = 0;
gdjs.GameCode.GDEnemyObjects1.length = 0;
gdjs.GameCode.GDEnemyObjects2.length = 0;
gdjs.GameCode.GDCenterObjects1.length = 0;
gdjs.GameCode.GDCenterObjects2.length = 0;
gdjs.GameCode.GDSpawnPointsObjects1.length = 0;
gdjs.GameCode.GDSpawnPointsObjects2.length = 0;
gdjs.GameCode.GDCOSObjects1.length = 0;
gdjs.GameCode.GDCOSObjects2.length = 0;

gdjs.GameCode.eventsList0(runtimeScene);

return;

}

gdjs['GameCode'] = gdjs.GameCode;
