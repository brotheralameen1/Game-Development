gdjs.Dev_95SuppCode = {};
gdjs.Dev_95SuppCode.GDDescriptionObjects1= [];
gdjs.Dev_95SuppCode.GDDescriptionObjects2= [];
gdjs.Dev_95SuppCode.GDBackObjects1= [];
gdjs.Dev_95SuppCode.GDBackObjects2= [];
gdjs.Dev_95SuppCode.GDCryptoObjects1= [];
gdjs.Dev_95SuppCode.GDCryptoObjects2= [];
gdjs.Dev_95SuppCode.GDYT_9595ChannelObjects1= [];
gdjs.Dev_95SuppCode.GDYT_9595ChannelObjects2= [];
gdjs.Dev_95SuppCode.GDQuitObjects1= [];
gdjs.Dev_95SuppCode.GDQuitObjects2= [];
gdjs.Dev_95SuppCode.GDDesc_9595TextObjects1= [];
gdjs.Dev_95SuppCode.GDDesc_9595TextObjects2= [];
gdjs.Dev_95SuppCode.GDAddiesObjects1= [];
gdjs.Dev_95SuppCode.GDAddiesObjects2= [];
gdjs.Dev_95SuppCode.GDYTCObjects1= [];
gdjs.Dev_95SuppCode.GDYTCObjects2= [];
gdjs.Dev_95SuppCode.GDBCKObjects1= [];
gdjs.Dev_95SuppCode.GDBCKObjects2= [];
gdjs.Dev_95SuppCode.GDQuit2Objects1= [];
gdjs.Dev_95SuppCode.GDQuit2Objects2= [];


gdjs.Dev_95SuppCode.mapOfGDgdjs_9546Dev_959595SuppCode_9546GDBackObjects1Objects = Hashtable.newFrom({"Back": gdjs.Dev_95SuppCode.GDBackObjects1});
gdjs.Dev_95SuppCode.mapOfGDgdjs_9546Dev_959595SuppCode_9546GDCryptoObjects1Objects = Hashtable.newFrom({"Crypto": gdjs.Dev_95SuppCode.GDCryptoObjects1});
gdjs.Dev_95SuppCode.mapOfGDgdjs_9546Dev_959595SuppCode_9546GDYT_95959595ChannelObjects1Objects = Hashtable.newFrom({"YT_Channel": gdjs.Dev_95SuppCode.GDYT_9595ChannelObjects1});
gdjs.Dev_95SuppCode.mapOfGDgdjs_9546Dev_959595SuppCode_9546GDQuitObjects1Objects = Hashtable.newFrom({"Quit": gdjs.Dev_95SuppCode.GDQuitObjects1});
gdjs.Dev_95SuppCode.eventsList0 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.Dev_95SuppCode.GDBackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Dev_95SuppCode.mapOfGDgdjs_9546Dev_959595SuppCode_9546GDBackObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Start_Menu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Crypto"), gdjs.Dev_95SuppCode.GDCryptoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Dev_95SuppCode.mapOfGDgdjs_9546Dev_959595SuppCode_9546GDCryptoObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://pastebin.com/hvswspz1", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("YT_Channel"), gdjs.Dev_95SuppCode.GDYT_9595ChannelObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Dev_95SuppCode.mapOfGDgdjs_9546Dev_959595SuppCode_9546GDYT_95959595ChannelObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://www.youtube.com/channel/UCRmZnjgfrD7al_h-cyOdQLA", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quit"), gdjs.Dev_95SuppCode.GDQuitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Dev_95SuppCode.mapOfGDgdjs_9546Dev_959595SuppCode_9546GDQuitObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


};

gdjs.Dev_95SuppCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Dev_95SuppCode.GDDescriptionObjects1.length = 0;
gdjs.Dev_95SuppCode.GDDescriptionObjects2.length = 0;
gdjs.Dev_95SuppCode.GDBackObjects1.length = 0;
gdjs.Dev_95SuppCode.GDBackObjects2.length = 0;
gdjs.Dev_95SuppCode.GDCryptoObjects1.length = 0;
gdjs.Dev_95SuppCode.GDCryptoObjects2.length = 0;
gdjs.Dev_95SuppCode.GDYT_9595ChannelObjects1.length = 0;
gdjs.Dev_95SuppCode.GDYT_9595ChannelObjects2.length = 0;
gdjs.Dev_95SuppCode.GDQuitObjects1.length = 0;
gdjs.Dev_95SuppCode.GDQuitObjects2.length = 0;
gdjs.Dev_95SuppCode.GDDesc_9595TextObjects1.length = 0;
gdjs.Dev_95SuppCode.GDDesc_9595TextObjects2.length = 0;
gdjs.Dev_95SuppCode.GDAddiesObjects1.length = 0;
gdjs.Dev_95SuppCode.GDAddiesObjects2.length = 0;
gdjs.Dev_95SuppCode.GDYTCObjects1.length = 0;
gdjs.Dev_95SuppCode.GDYTCObjects2.length = 0;
gdjs.Dev_95SuppCode.GDBCKObjects1.length = 0;
gdjs.Dev_95SuppCode.GDBCKObjects2.length = 0;
gdjs.Dev_95SuppCode.GDQuit2Objects1.length = 0;
gdjs.Dev_95SuppCode.GDQuit2Objects2.length = 0;

gdjs.Dev_95SuppCode.eventsList0(runtimeScene);

return;

}

gdjs['Dev_95SuppCode'] = gdjs.Dev_95SuppCode;
