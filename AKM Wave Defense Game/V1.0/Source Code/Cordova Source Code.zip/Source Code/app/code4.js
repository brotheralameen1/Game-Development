gdjs.Game_95OverCode = {};
gdjs.Game_95OverCode.GDGame_9595OverObjects1= [];
gdjs.Game_95OverCode.GDGame_9595OverObjects2= [];
gdjs.Game_95OverCode.GDGOverObjects1= [];
gdjs.Game_95OverCode.GDGOverObjects2= [];
gdjs.Game_95OverCode.GDDemon_9595MessageObjects1= [];
gdjs.Game_95OverCode.GDDemon_9595MessageObjects2= [];
gdjs.Game_95OverCode.GDInverted_9595PentegramObjects1= [];
gdjs.Game_95OverCode.GDInverted_9595PentegramObjects2= [];
gdjs.Game_95OverCode.GDLoveObjects1= [];
gdjs.Game_95OverCode.GDLoveObjects2= [];
gdjs.Game_95OverCode.GDAll_9595HailObjects1= [];
gdjs.Game_95OverCode.GDAll_9595HailObjects2= [];
gdjs.Game_95OverCode.GDPlay_9595AgainObjects1= [];
gdjs.Game_95OverCode.GDPlay_9595AgainObjects2= [];
gdjs.Game_95OverCode.GDStart_9595MenuObjects1= [];
gdjs.Game_95OverCode.GDStart_9595MenuObjects2= [];
gdjs.Game_95OverCode.GDExitObjects1= [];
gdjs.Game_95OverCode.GDExitObjects2= [];
gdjs.Game_95OverCode.GDPlay_9595Again2Objects1= [];
gdjs.Game_95OverCode.GDPlay_9595Again2Objects2= [];
gdjs.Game_95OverCode.GDMain_9595MenuObjects1= [];
gdjs.Game_95OverCode.GDMain_9595MenuObjects2= [];
gdjs.Game_95OverCode.GDQuitObjects1= [];
gdjs.Game_95OverCode.GDQuitObjects2= [];


gdjs.Game_95OverCode.mapOfGDgdjs_9546Game_959595OverCode_9546GDPlay_95959595AgainObjects1Objects = Hashtable.newFrom({"Play_Again": gdjs.Game_95OverCode.GDPlay_9595AgainObjects1});
gdjs.Game_95OverCode.mapOfGDgdjs_9546Game_959595OverCode_9546GDStart_95959595MenuObjects1Objects = Hashtable.newFrom({"Start_Menu": gdjs.Game_95OverCode.GDStart_9595MenuObjects1});
gdjs.Game_95OverCode.mapOfGDgdjs_9546Game_959595OverCode_9546GDExitObjects1Objects = Hashtable.newFrom({"Exit": gdjs.Game_95OverCode.GDExitObjects1});
gdjs.Game_95OverCode.eventsList0 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Play_Again"), gdjs.Game_95OverCode.GDPlay_9595AgainObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Game_95OverCode.mapOfGDgdjs_9546Game_959595OverCode_9546GDPlay_95959595AgainObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Start_Menu"), gdjs.Game_95OverCode.GDStart_9595MenuObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Game_95OverCode.mapOfGDgdjs_9546Game_959595OverCode_9546GDStart_95959595MenuObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Start_Menu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.Game_95OverCode.GDExitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Game_95OverCode.mapOfGDgdjs_9546Game_959595OverCode_9546GDExitObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Game_95OverCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_95OverCode.GDGame_9595OverObjects1.length = 0;
gdjs.Game_95OverCode.GDGame_9595OverObjects2.length = 0;
gdjs.Game_95OverCode.GDGOverObjects1.length = 0;
gdjs.Game_95OverCode.GDGOverObjects2.length = 0;
gdjs.Game_95OverCode.GDDemon_9595MessageObjects1.length = 0;
gdjs.Game_95OverCode.GDDemon_9595MessageObjects2.length = 0;
gdjs.Game_95OverCode.GDInverted_9595PentegramObjects1.length = 0;
gdjs.Game_95OverCode.GDInverted_9595PentegramObjects2.length = 0;
gdjs.Game_95OverCode.GDLoveObjects1.length = 0;
gdjs.Game_95OverCode.GDLoveObjects2.length = 0;
gdjs.Game_95OverCode.GDAll_9595HailObjects1.length = 0;
gdjs.Game_95OverCode.GDAll_9595HailObjects2.length = 0;
gdjs.Game_95OverCode.GDPlay_9595AgainObjects1.length = 0;
gdjs.Game_95OverCode.GDPlay_9595AgainObjects2.length = 0;
gdjs.Game_95OverCode.GDStart_9595MenuObjects1.length = 0;
gdjs.Game_95OverCode.GDStart_9595MenuObjects2.length = 0;
gdjs.Game_95OverCode.GDExitObjects1.length = 0;
gdjs.Game_95OverCode.GDExitObjects2.length = 0;
gdjs.Game_95OverCode.GDPlay_9595Again2Objects1.length = 0;
gdjs.Game_95OverCode.GDPlay_9595Again2Objects2.length = 0;
gdjs.Game_95OverCode.GDMain_9595MenuObjects1.length = 0;
gdjs.Game_95OverCode.GDMain_9595MenuObjects2.length = 0;
gdjs.Game_95OverCode.GDQuitObjects1.length = 0;
gdjs.Game_95OverCode.GDQuitObjects2.length = 0;

gdjs.Game_95OverCode.eventsList0(runtimeScene);

return;

}

gdjs['Game_95OverCode'] = gdjs.Game_95OverCode;
