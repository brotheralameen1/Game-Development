gdjs.Start_95MenuCode = {};
gdjs.Start_95MenuCode.GDDescriptorObjects1= [];
gdjs.Start_95MenuCode.GDDescriptorObjects2= [];
gdjs.Start_95MenuCode.GDGame_9595NameObjects1= [];
gdjs.Start_95MenuCode.GDGame_9595NameObjects2= [];
gdjs.Start_95MenuCode.GDStart_9595GameObjects1= [];
gdjs.Start_95MenuCode.GDStart_9595GameObjects2= [];
gdjs.Start_95MenuCode.GDHow_9595to_9595playObjects1= [];
gdjs.Start_95MenuCode.GDHow_9595to_9595playObjects2= [];
gdjs.Start_95MenuCode.GDYouTube_9595Channel_9595and_9595Crypto_9595AddressObjects1= [];
gdjs.Start_95MenuCode.GDYouTube_9595Channel_9595and_9595Crypto_9595AddressObjects2= [];
gdjs.Start_95MenuCode.GDExitObjects1= [];
gdjs.Start_95MenuCode.GDExitObjects2= [];
gdjs.Start_95MenuCode.GDStart_9595Game1Objects1= [];
gdjs.Start_95MenuCode.GDStart_9595Game1Objects2= [];
gdjs.Start_95MenuCode.GDhow_9595to_9595play1Objects1= [];
gdjs.Start_95MenuCode.GDhow_9595to_9595play1Objects2= [];
gdjs.Start_95MenuCode.GDDev_9595SupObjects1= [];
gdjs.Start_95MenuCode.GDDev_9595SupObjects2= [];
gdjs.Start_95MenuCode.GDquit_9595game1Objects1= [];
gdjs.Start_95MenuCode.GDquit_9595game1Objects2= [];


gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDStart_95959595Game1Objects1Objects = Hashtable.newFrom({"Start_Game1": gdjs.Start_95MenuCode.GDStart_9595Game1Objects1});
gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDquit_95959595game1Objects1Objects = Hashtable.newFrom({"quit_game1": gdjs.Start_95MenuCode.GDquit_9595game1Objects1});
gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDhow_95959595to_95959595play1Objects1Objects = Hashtable.newFrom({"how_to_play1": gdjs.Start_95MenuCode.GDhow_9595to_9595play1Objects1});
gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDDev_95959595SupObjects1Objects = Hashtable.newFrom({"Dev_Sup": gdjs.Start_95MenuCode.GDDev_9595SupObjects1});
gdjs.Start_95MenuCode.eventsList0 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Start_Game1"), gdjs.Start_95MenuCode.GDStart_9595Game1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDStart_95959595Game1Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("quit_game1"), gdjs.Start_95MenuCode.GDquit_9595game1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDquit_95959595game1Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("how_to_play1"), gdjs.Start_95MenuCode.GDhow_9595to_9595play1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDhow_95959595to_95959595play1Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "How_To_Play", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Dev_Sup"), gdjs.Start_95MenuCode.GDDev_9595SupObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDDev_95959595SupObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Dev_Supp", false);
}}

}


};

gdjs.Start_95MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Start_95MenuCode.GDDescriptorObjects1.length = 0;
gdjs.Start_95MenuCode.GDDescriptorObjects2.length = 0;
gdjs.Start_95MenuCode.GDGame_9595NameObjects1.length = 0;
gdjs.Start_95MenuCode.GDGame_9595NameObjects2.length = 0;
gdjs.Start_95MenuCode.GDStart_9595GameObjects1.length = 0;
gdjs.Start_95MenuCode.GDStart_9595GameObjects2.length = 0;
gdjs.Start_95MenuCode.GDHow_9595to_9595playObjects1.length = 0;
gdjs.Start_95MenuCode.GDHow_9595to_9595playObjects2.length = 0;
gdjs.Start_95MenuCode.GDYouTube_9595Channel_9595and_9595Crypto_9595AddressObjects1.length = 0;
gdjs.Start_95MenuCode.GDYouTube_9595Channel_9595and_9595Crypto_9595AddressObjects2.length = 0;
gdjs.Start_95MenuCode.GDExitObjects1.length = 0;
gdjs.Start_95MenuCode.GDExitObjects2.length = 0;
gdjs.Start_95MenuCode.GDStart_9595Game1Objects1.length = 0;
gdjs.Start_95MenuCode.GDStart_9595Game1Objects2.length = 0;
gdjs.Start_95MenuCode.GDhow_9595to_9595play1Objects1.length = 0;
gdjs.Start_95MenuCode.GDhow_9595to_9595play1Objects2.length = 0;
gdjs.Start_95MenuCode.GDDev_9595SupObjects1.length = 0;
gdjs.Start_95MenuCode.GDDev_9595SupObjects2.length = 0;
gdjs.Start_95MenuCode.GDquit_9595game1Objects1.length = 0;
gdjs.Start_95MenuCode.GDquit_9595game1Objects2.length = 0;

gdjs.Start_95MenuCode.eventsList0(runtimeScene);

return;

}

gdjs['Start_95MenuCode'] = gdjs.Start_95MenuCode;
