gdjs.Start_95MenuCode = {};
gdjs.Start_95MenuCode.GDIntroObjects1= [];
gdjs.Start_95MenuCode.GDIntroObjects2= [];
gdjs.Start_95MenuCode.GDWelcomeObjects1= [];
gdjs.Start_95MenuCode.GDWelcomeObjects2= [];
gdjs.Start_95MenuCode.GDStart_9595GameObjects1= [];
gdjs.Start_95MenuCode.GDStart_9595GameObjects2= [];
gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects1= [];
gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects2= [];
gdjs.Start_95MenuCode.GDContributeObjects1= [];
gdjs.Start_95MenuCode.GDContributeObjects2= [];
gdjs.Start_95MenuCode.GDQuitObjects1= [];
gdjs.Start_95MenuCode.GDQuitObjects2= [];
gdjs.Start_95MenuCode.GDPlayObjects1= [];
gdjs.Start_95MenuCode.GDPlayObjects2= [];
gdjs.Start_95MenuCode.GDHow_9595ToObjects1= [];
gdjs.Start_95MenuCode.GDHow_9595ToObjects2= [];
gdjs.Start_95MenuCode.GDContribObjects1= [];
gdjs.Start_95MenuCode.GDContribObjects2= [];
gdjs.Start_95MenuCode.GDExitObjects1= [];
gdjs.Start_95MenuCode.GDExitObjects2= [];


gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDStart_95959595GameObjects1Objects = Hashtable.newFrom({"Start_Game": gdjs.Start_95MenuCode.GDStart_9595GameObjects1});
gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDHow_95959595To_95959595PlayObjects1Objects = Hashtable.newFrom({"How_To_Play": gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects1});
gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDContributeObjects1Objects = Hashtable.newFrom({"Contribute": gdjs.Start_95MenuCode.GDContributeObjects1});
gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDQuitObjects1Objects = Hashtable.newFrom({"Quit": gdjs.Start_95MenuCode.GDQuitObjects1});
gdjs.Start_95MenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Start_Game"), gdjs.Start_95MenuCode.GDStart_9595GameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDStart_95959595GameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("How_To_Play"), gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDHow_95959595To_95959595PlayObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "How_To_Play", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Contribute"), gdjs.Start_95MenuCode.GDContributeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDContributeObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Contribute", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quit"), gdjs.Start_95MenuCode.GDQuitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Start_95MenuCode.mapOfGDgdjs_9546Start_959595MenuCode_9546GDQuitObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Start_95MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Start_95MenuCode.GDIntroObjects1.length = 0;
gdjs.Start_95MenuCode.GDIntroObjects2.length = 0;
gdjs.Start_95MenuCode.GDWelcomeObjects1.length = 0;
gdjs.Start_95MenuCode.GDWelcomeObjects2.length = 0;
gdjs.Start_95MenuCode.GDStart_9595GameObjects1.length = 0;
gdjs.Start_95MenuCode.GDStart_9595GameObjects2.length = 0;
gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects1.length = 0;
gdjs.Start_95MenuCode.GDHow_9595To_9595PlayObjects2.length = 0;
gdjs.Start_95MenuCode.GDContributeObjects1.length = 0;
gdjs.Start_95MenuCode.GDContributeObjects2.length = 0;
gdjs.Start_95MenuCode.GDQuitObjects1.length = 0;
gdjs.Start_95MenuCode.GDQuitObjects2.length = 0;
gdjs.Start_95MenuCode.GDPlayObjects1.length = 0;
gdjs.Start_95MenuCode.GDPlayObjects2.length = 0;
gdjs.Start_95MenuCode.GDHow_9595ToObjects1.length = 0;
gdjs.Start_95MenuCode.GDHow_9595ToObjects2.length = 0;
gdjs.Start_95MenuCode.GDContribObjects1.length = 0;
gdjs.Start_95MenuCode.GDContribObjects2.length = 0;
gdjs.Start_95MenuCode.GDExitObjects1.length = 0;
gdjs.Start_95MenuCode.GDExitObjects2.length = 0;

gdjs.Start_95MenuCode.eventsList0(runtimeScene);

return;

}

gdjs['Start_95MenuCode'] = gdjs.Start_95MenuCode;
